<!DOCTYPE HTML> <html lang="en" dir="ltr"> <head>         <meta charset="UTF-8"/> <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/> <meta http-equiv="x-ua-compatible" content="ie=edge"/> <link rel="SHORTCUT ICON" href="/favicon.ico?v2" type="image/x-icon"/> <meta name="robots" content="index, follow"/> <meta name="template" content="onecloud-marketing-template0"/> <meta name="awa-canvasType" content="web"/> <meta name="awa-isTented" content="false"/> <meta name="awa-pageType" content="Microsoft 365"/> <meta name="awa-market" content="en"/> <meta name="awa-cms" content="AEM"/> <meta name="awa-enabledFeatures" content="contentbackfillgenerate;esiproductcards;uhf-ms-io-endpoint;uhf-esi-cv;uhf-esi-cache;fraud-greenid;contentsquare;mediapixel;holiday-themer;lazyload-static-components;clientlibDefer;upsellEnabled;contentbackfillpkgdelete;healthcheck;demo-feature;contentbackfillhttpgenerate;perf-tracker-1ds;dynamic-bundle;cvIncrementer;tentingEnabled;chatCookiesImplemented;alertCountDownWithoutServerTime;pdpDynamicRendering;bundlesDynamicRendering;contentbackfillmetadatachangesvideo;contentbackfillmetadatachangesnonvideo;listDynamicRendering;experimentation-without-personalization;generic-list-importer;combinedUHF;cvCallEnabled;m365ProductCatalog;support-unsupported-locales;deferClickTale;videoLazyLoad;prefetchFontsEnabled;enable-code-isolation;imageLinkTag;fetchPriority;contentIngestionAgent;enableClickgroupTelemetry;imageLazyLoad;contentIngestionAgent-dispatcher2westus2Agent;isCacheControlFeatureEnabled;lcpPrioritizationPhase1;ocReimagineTelemetry;deferScriptsEnabled;lcpPrioritizationPhase2;contentIngestionAgent-dispatcher1westus2Agent;extended-html-minification-sites"/> <title>Microsoft Outlook Personal Email and Calendar | Microsoft 365</title> <link rel="canonical" href="https://www.microsoft.com/en/microsoft-365/outlook/email-and-calendar-software-microsoft-outlook"/> <meta name="description" content="Download free Microsoft Outlook email and calendar, plus Office Online apps like Word, Excel, and PowerPoint. Sign in to access your Outlook email account."/> <meta name="twitter:url" content="https://www.microsoft.com/en/microsoft-365/outlook/email-and-calendar-software-microsoft-outlook"/> <meta name="twitter:title" content="Microsoft Outlook Personal Email and Calendar | Microsoft 365"/> <meta name="twitter:description" content="Download free Microsoft Outlook email and calendar, plus Office Online apps like Word, Excel, and PowerPoint. Sign in to access your Outlook email account."/> <meta name="twitter:card" content="summary"/> <meta property="og:url" content="https://www.microsoft.com/en/microsoft-365/outlook/email-and-calendar-software-microsoft-outlook"/> <meta property="og:title" content="Microsoft Outlook Personal Email and Calendar | Microsoft 365"/> <meta property="og:description" content="Download free Microsoft Outlook email and calendar, plus Office Online apps like Word, Excel, and PowerPoint. Sign in to access your Outlook email account."/> <meta property="og:type" content="website"/> <link rel="stylesheet" href="/etc.clientlibs/onecloud/clientlibs/clientlib-mwf-new/main-outlook.min.ACSHASH1d3f816b509debff5108d71034fb436e.css" type="text/css"> <link rel="stylesheet" href="/etc.clientlibs/onecloud/clientlibs/clientlib-mwf-ext/main-outlook.min.ACSHASH902dd1e162e1410f006c5c1f3867b0cd.css" type="text/css"> <link rel="stylesheet" href="/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-base.min.ACSHASHc5871451778c8e6454258da6f73224b7.css" type="text/css"> <script src="/etc.clientlibs/onecloud/clientlibs/clientlib-events.min.ACSHASH1e1e807a22bd65d9f61a48a38d6e7faa.js"></script> <link rel="stylesheet" href="/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-uhf.min.ACSHASHf9f2395c582fa601707b7a5dfae9f05f.css" type="text/css">  <script>oc.geo.country = "FR";</script>  <script id="ie11-polyfill-script">

        var isModernBrowser = (
            'fetch' in window &&
            'assign' in Object
        );

        if ( !isModernBrowser ) {
            var scriptElement = document.createElement('script');

            scriptElement.async = false;
            scriptElement.src = '/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-polyfills/resources/ie11-polyfills.js';

            var polyfillScriptElement = document.querySelector('#ie11-polyfill-script');

            if (polyfillScriptElement) {
                polyfillScriptElement.parentNode.insertBefore(scriptElement, polyfillScriptElement.nextSibling);
            }
        }
    </script> <script src="/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-polyfills.min.ACSHASHf381d5147c85ee687ea8fbef32c83d37.js"></script> <script src="/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-jquery.min.ACSHASH35986a813756f39ab6b922979ffedb03.js"></script> <script src="/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-jquery-cookie.min.ACSHASH20aafdf6904d3dc5db0e0e33abbfc1a4.js"></script> <script type="text/javascript" src="https://az725175.vo.msecnd.net/scripts/jsll-4.js"></script>  <script src="/etc.clientlibs/microsoft/clientlibs/exp-analytics/v1.min.ACSHASH4cffc2c9b55f8bde649e0d2535a1eebd.js"></script> <script type="text/javascript">
                var expToken = {
                    "exp": {
                        "target": {
                            "propertyToken": "3c148cf5-9769-f782-32c4-14f7eba5d269",
                            "visitorJsHash": "30368a72d017e4133bfd3b5d073d06ff",
                            "expJsHash": "895e2a12062f1ee44d7d72d266904bde",
                            "isExpWithoutPersonalizationEnabled": ("false"==="true")
                        }
                    }
                };
                window.cas = expToken;
            </script> <script type="text/javascript" src="/etc.clientlibs/microsoft/clientlibs/exp-cookiecomp/v1.min.ACSHASHc343dfb005ac8c14ae0dd22dd17fb2fc.js" async></script> <meta name="exp-visitor-anchor" content=""/>         <meta name="exp-atjs-anchor" content=""/>  <link id="onecloud-head-style" href="https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RE4OFm4" type="text/css" rel="stylesheet"/> <script id="onecloud-head-script" type="text/javascript" src="https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RE4OxzH" async></script> </head> <body class="page basicpage"> <span style="display:none">   <script>
  	  			window.mscv = 'CASMicrosoftCVb0bf4a9b.0'
  			</script>         <script>
  	  			window.msservercv = 'CASMicrosoftCVb0bf4a9b.0'
  			</script>    <script>
					window.traceid = undefined;
				</script>  </span> <script type="text/javascript">
		window.msauthIsPublisher = true;
	</script>        <span aria-hidden="true" class="d-none geo-info" data-continent="EU" data-country_code="FR" data-region_code="IDF" data-city="PARIS" data-timezone="GMT+1" data-zip="" data-county="" data-areacode=""> </span>  <div id="page-top" tabindex="-1"></div> <div id="modalsRenderedAfterPageLoad"> </div> <div class="root responsivegrid"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 "> <div class="universalheader aem-GridColumn aem-GridColumn--default--12" data-component-id="cf9a86dceae618e01d6e6399d243873c">         <link rel="stylesheet" href="https://www.microsoft.com/onerfstatics/marketingsites-neu-prod/west-european/shell/_scrf/css/themes=default.device=uplevel_web_pc/79-4cdd0a/33-ae3d41/a5-4bf7a2/13-8e1ceb/81-32f0c0/5c-b7b685/92-14707b/74-888e54?ver=2.0&amp;_cf=20210618" type="text/css" media="all" />    <div id="headerArea" class="uhf"  data-m='{"cN":"headerArea","cT":"Area_coreuiArea","id":"a1Body","sN":1,"aN":"Body"}'>
                <div id="headerRegion"      data-region-key="headerregion" data-m='{"cN":"headerRegion","cT":"Region_coreui-region","id":"r1a1","sN":1,"aN":"a1"}' >

    <div  id="headerUniversalHeader" data-m='{"cN":"headerUniversalHeader","cT":"Module_coreui-universalheader","id":"m1r1a1","sN":1,"aN":"r1a1"}'  data-module-id="Category|headerRegion|coreui-region|headerUniversalHeader|coreui-universalheader">
        


                        <div data-m='{"cN":"cookiebanner_cont","cT":"Container","id":"c1m1r1a1","sN":1,"aN":"m1r1a1"}'>

<div id="uhfCookieAlert" data-locale="en-ww">
    <div id="msccBannerV2"></div>
</div>

                            
                        </div>




        <a id="uhfSkipToMain" class="m-skip-to-main" href="javascript:void(0)" data-href="#mainContent" tabindex="0" data-m='{"cN":"Skip to content_nonnav","id":"nn2m1r1a1","sN":2,"aN":"m1r1a1"}'>Skip to main content</a>


<header class="c-uhfh context-uhf no-js c-sgl-stck c-category-header " itemscope="itemscope" data-header-footprint="/OfficeProducts/m365-outlookheader, fromService: True"   data-magict="true"   itemtype="http://schema.org/Organization">
    <div class="theme-light js-global-head f-closed  global-head-cont" data-m='{"cN":"Universal Header_cont","cT":"Container","id":"c3m1r1a1","sN":3,"aN":"m1r1a1"}'>
        <div class="c-uhfh-gcontainer-st">
            <button type="button" class="c-action-trigger c-glyph glyph-global-nav-button" aria-label="All Microsoft expand to see list of Microsoft products and services" initialState-label="All Microsoft expand to see list of Microsoft products and services" toggleState-label="Close All Microsoft list" aria-expanded="false" data-m='{"cN":"Mobile menu button_nonnav","id":"nn1c3m1r1a1","sN":1,"aN":"c3m1r1a1"}'></button>
            <button type="button" class="c-action-trigger c-glyph glyph-arrow-htmllegacy c-close-search" aria-label="Close search" aria-expanded="false" data-m='{"cN":"Close Search_nonnav","id":"nn2c3m1r1a1","sN":2,"aN":"c3m1r1a1"}'></button>
                    <a id="uhfLogo" class="c-logo c-sgl-stk-uhfLogo" itemprop="url" href="https://www.microsoft.com" aria-label="Microsoft" data-m='{"cN":"GlobalNav_Logo_cont","cT":"Container","id":"c3c3m1r1a1","sN":3,"aN":"c3m1r1a1"}'>
                        <img alt="" itemprop="logo" class="c-image" src="https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE1Mu3b?ver=5c31" role="presentation" aria-hidden="true" />
                        <span itemprop="name" role="presentation" aria-hidden="true">Microsoft</span>
                    </a>
            <div class="f-mobile-title">
                <button type="button" class="c-action-trigger c-glyph glyph-chevron-left" aria-label="See more menu options" data-m='{"cN":"Mobile back button_nonnav","id":"nn4c3m1r1a1","sN":4,"aN":"c3m1r1a1"}'></button>
                <span data-global-title="Microsoft home" class="js-mobile-title">Microsoft 365</span>
                <button type="button" class="c-action-trigger c-glyph glyph-chevron-right" aria-label="See more menu options" data-m='{"cN":"Mobile forward button_nonnav","id":"nn5c3m1r1a1","sN":5,"aN":"c3m1r1a1"}'></button>
            </div>
                    <div class="c-show-pipe x-hidden-vp-mobile-st">
                        <a id="uhfCatLogo" class="c-logo c-cat-logo" href="https://www.microsoft.com/en-ww/microsoft-365" aria-label="Microsoft 365" itemprop="url" data-m='{"cN":"CatNav_Microsoft 365_nav","id":"n6c3m1r1a1","sN":6,"aN":"c3m1r1a1"}'>
                                <span>Microsoft 365</span>
                        </a>
                    </div>
                <div class="cat-logo-button-cont x-hidden">
                        <button type="button" id="uhfCatLogoButton" class="c-cat-logo-button x-hidden" aria-expanded="false" aria-label="Microsoft 365" data-m='{"cN":"Microsoft 365_nonnav","id":"nn7c3m1r1a1","sN":7,"aN":"c3m1r1a1"}'>
                            Microsoft 365
                        </button>
                </div>



                    <nav id="uhf-g-nav" aria-label="Contextual menu" class="c-uhfh-gnav" data-m='{"cN":"Category nav_cont","cT":"Container","id":"c8c3m1r1a1","sN":8,"aN":"c3m1r1a1"}'>
            <ul class="js-paddle-items">
                    <li class="single-link js-nav-menu x-hidden-none-mobile-vp uhf-menu-item">
                        <a class="c-uhf-nav-link" href="https://www.microsoft.com/en-ww/microsoft-365" data-m='{"cN":"CatNav_Home_nav","id":"n1c8c3m1r1a1","sN":1,"aN":"c8c3m1r1a1"}' > Home </a>
                    </li>
                                        <li class="single-link js-nav-menu uhf-menu-item">
                            <a id="c-shellmenu_0" class="c-uhf-nav-link" href="https://www.microsoft.com/en-ww/microsoft-365/outlook/email-and-calendar-software-microsoft-outlook" data-m='{"id":"n2c8c3m1r1a1","sN":2,"aN":"c8c3m1r1a1"}'>Outlook</a>
                        </li>
                        <li class="single-link js-nav-menu uhf-menu-item">
                            <a id="c-shellmenu_1" class="c-uhf-nav-link" href="https://www.microsoft.com/en-ww/microsoft-365/outlook/outlook-for-business" data-m='{"id":"n3c8c3m1r1a1","sN":3,"aN":"c8c3m1r1a1"}'>For business</a>
                        </li>
                        <li class="nested-menu uhf-menu-item">
                            <div class="c-uhf-menu js-nav-menu">
                                <button type="button" id="c-shellmenu_2"  aria-expanded="false" data-m='{"id":"nn4c8c3m1r1a1","sN":4,"aN":"c8c3m1r1a1"}'>Plans and pricing</button>

                                <ul class="" data-class-idn="" aria-hidden="true" data-m='{"cT":"Container","id":"c5c8c3m1r1a1","sN":5,"aN":"c8c3m1r1a1"}'>
        <li class="js-nav-menu single-link" data-m='{"cT":"Container","id":"c1c5c8c3m1r1a1","sN":1,"aN":"c5c8c3m1r1a1"}'>
            <a id="c-shellmenu_3" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-ww/microsoft-365/buy/compare-all-microsoft-365-products" data-m='{"id":"n1c1c5c8c3m1r1a1","sN":1,"aN":"c1c5c8c3m1r1a1"}'>For home</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cT":"Container","id":"c2c5c8c3m1r1a1","sN":2,"aN":"c5c8c3m1r1a1"}'>
            <a id="c-shellmenu_4" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-ww/microsoft-365/compare-all-microsoft-365-products?&amp;activetab=tab:primaryr2" data-m='{"id":"n1c2c5c8c3m1r1a1","sN":1,"aN":"c2c5c8c3m1r1a1"}'>For business</a>
            
        </li>
                                                    
                                </ul>
                            </div>
                        </li>                        <li class="single-link js-nav-menu uhf-menu-item">
                            <a id="c-shellmenu_5" class="c-uhf-nav-link" href="https://support.office.com/en-us/outlook" data-m='{"id":"n6c8c3m1r1a1","sN":6,"aN":"c8c3m1r1a1"}'>Support</a>
                        </li>


                <li id="overflow-menu" class="overflow-menu x-hidden uhf-menu-item">
                        <div class="c-uhf-menu js-nav-menu">
        <button data-m='{"pid":"More","id":"nn7c8c3m1r1a1","sN":7,"aN":"c8c3m1r1a1"}' type="button" aria-label="More" aria-expanded="false">More</button>
        <ul id="overflow-menu-list" aria-hidden="true" class="overflow-menu-list">
        </ul>
    </div>

                </li>
                                    <li class="single-link js-nav-menu" id="c-uhf-nav-cta">
                        <a  class="c-uhf-nav-link" href="https://www.microsoft.com/en-ww/microsoft-365/buy/compare-all-microsoft-365-products" data-m='{"cN":"CatNav_cta_Buy now_nav","id":"n8c8c3m1r1a1","sN":8,"aN":"c8c3m1r1a1"}'>Buy now</a>
                    </li>
            </ul>
            
        </nav>


            <div class="c-uhfh-actions" data-m='{"cN":"Header actions_cont","cT":"Container","id":"c9c3m1r1a1","sN":9,"aN":"c3m1r1a1"}'>
                <div class="wf-menu">        <nav id="uhf-c-nav" aria-label="All Microsoft menu" data-m='{"cN":"GlobalNav_cont","cT":"Container","id":"c1c9c3m1r1a1","sN":1,"aN":"c9c3m1r1a1"}'>
            <ul class="js-paddle-items">
                <li>
                    <div class="c-uhf-menu js-nav-menu">
                        <button type="button" class="c-button-logo all-ms-nav" aria-expanded="false" data-m='{"cN":"GlobalNav_More_nonnav","id":"nn1c1c9c3m1r1a1","sN":1,"aN":"c1c9c3m1r1a1"}'> <span>All Microsoft</span></button>
                        <ul class="f-multi-column f-multi-column-6" aria-hidden="true" data-m='{"cN":"More_cont","cT":"Container","id":"c2c1c9c3m1r1a1","sN":2,"aN":"c1c9c3m1r1a1"}'>
                                    <li class="c-w0-contr">
            <h2 class="c-uhf-sronly">Global</h2>
            <ul class="c-w0">
        <li class="js-nav-menu single-link" data-m='{"cN":"M365_cont","cT":"Container","id":"c1c2c1c9c3m1r1a1","sN":1,"aN":"c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_6" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/microsoft-365" data-m='{"cN":"W0Nav_M365_nav","id":"n1c1c2c1c9c3m1r1a1","sN":1,"aN":"c1c2c1c9c3m1r1a1"}'>Microsoft 365</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Teams_cont","cT":"Container","id":"c2c2c1c9c3m1r1a1","sN":2,"aN":"c2c1c9c3m1r1a1"}'>
            <a id="l0_Teams" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/microsoft-teams/group-chat-software" data-m='{"cN":"W0Nav_Teams_nav","id":"n1c2c2c1c9c3m1r1a1","sN":1,"aN":"c2c2c1c9c3m1r1a1"}'>Teams</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Windows_cont","cT":"Container","id":"c3c2c1c9c3m1r1a1","sN":3,"aN":"c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_8" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/windows/" data-m='{"cN":"W0Nav_Windows_nav","id":"n1c3c2c1c9c3m1r1a1","sN":1,"aN":"c3c2c1c9c3m1r1a1"}'>Windows</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Surface_cont","cT":"Container","id":"c4c2c1c9c3m1r1a1","sN":4,"aN":"c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_9" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/surface" data-m='{"cN":"W0Nav_Surface_nav","id":"n1c4c2c1c9c3m1r1a1","sN":1,"aN":"c4c2c1c9c3m1r1a1"}'>Surface</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Xbox_cont","cT":"Container","id":"c5c2c1c9c3m1r1a1","sN":5,"aN":"c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_10" class="js-subm-uhf-nav-link" href="https://www.xbox.com/" data-m='{"cN":"W0Nav_Xbox_nav","id":"n1c5c2c1c9c3m1r1a1","sN":1,"aN":"c5c2c1c9c3m1r1a1"}'>Xbox</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"Support_cont","cT":"Container","id":"c6c2c1c9c3m1r1a1","sN":6,"aN":"c2c1c9c3m1r1a1"}'>
            <a id="l1_support" class="js-subm-uhf-nav-link" href="https://support.microsoft.com" data-m='{"cN":"W0Nav_Support_nav","id":"n1c6c2c1c9c3m1r1a1","sN":1,"aN":"c6c2c1c9c3m1r1a1"}'>Support</a>
            
        </li>
            </ul>
        </li>

<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c7c2c1c9c3m1r1a1","sN":7,"aN":"c2c1c9c3m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_13-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c7c2c1c9c3m1r1a1","sN":1,"aN":"c7c2c1c9c3m1r1a1"}'>Software</span>
    <button id="uhf-navbtn-shellmenu_13-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c7c2c1c9c3m1r1a1","sN":2,"aN":"c7c2c1c9c3m1r1a1"}'>Software</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_13-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_AI_cont","cT":"Container","id":"c3c7c2c1c9c3m1r1a1","sN":3,"aN":"c7c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_14" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/ai" data-m='{"cN":"GlobalNav_More_Software_AI_nav","id":"n1c3c7c2c1c9c3m1r1a1","sN":1,"aN":"c3c7c2c1c9c3m1r1a1"}'>AI</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_OneDrive_cont","cT":"Container","id":"c4c7c2c1c9c3m1r1a1","sN":4,"aN":"c7c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_15" class="js-subm-uhf-nav-link" href="https://onedrive.live.com/about/en-us/" data-m='{"cN":"GlobalNav_More_Software_OneDrive_nav","id":"n1c4c7c2c1c9c3m1r1a1","sN":1,"aN":"c4c7c2c1c9c3m1r1a1"}'>OneDrive</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_Outlook_cont","cT":"Container","id":"c5c7c2c1c9c3m1r1a1","sN":5,"aN":"c7c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_16" class="js-subm-uhf-nav-link" href="https://outlook.live.com/owa/" data-m='{"cN":"GlobalNav_More_Software_Outlook_nav","id":"n1c5c7c2c1c9c3m1r1a1","sN":1,"aN":"c5c7c2c1c9c3m1r1a1"}'>Outlook</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_Skype_cont","cT":"Container","id":"c6c7c2c1c9c3m1r1a1","sN":6,"aN":"c7c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_17" class="js-subm-uhf-nav-link" href="https://www.skype.com/en/" data-m='{"cN":"GlobalNav_More_Software_Skype_nav","id":"n1c6c7c2c1c9c3m1r1a1","sN":1,"aN":"c6c7c2c1c9c3m1r1a1"}'>Skype</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Software_OneNote_cont","cT":"Container","id":"c7c7c2c1c9c3m1r1a1","sN":7,"aN":"c7c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_18" class="js-subm-uhf-nav-link" href="https://www.onenote.com/" data-m='{"cN":"GlobalNav_More_Software_OneNote_nav","id":"n1c7c7c2c1c9c3m1r1a1","sN":1,"aN":"c7c7c2c1c9c3m1r1a1"}'>OneNote</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cN":"PCsAndDevices_cont","cT":"Container","id":"c8c2c1c9c3m1r1a1","sN":8,"aN":"c2c1c9c3m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_19-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"GlobalNav_PCsAndDevices_nonnav","id":"nn1c8c2c1c9c3m1r1a1","sN":1,"aN":"c8c2c1c9c3m1r1a1"}'>PCs &amp; Devices  </span>
    <button id="uhf-navbtn-shellmenu_19-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"cN":"GlobalNav_PCsAndDevices_nonnav","id":"nn2c8c2c1c9c3m1r1a1","sN":2,"aN":"c8c2c1c9c3m1r1a1"}'>PCs &amp; Devices  </button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_19-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_PCsAndDevices_Accessories_cont","cT":"Container","id":"c3c8c2c1c9c3m1r1a1","sN":3,"aN":"c8c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_20" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-ww/accessories" data-m='{"cN":"GlobalNav_More_PCsAndDevices_Accessories_nav","id":"n1c3c8c2c1c9c3m1r1a1","sN":1,"aN":"c3c8c2c1c9c3m1r1a1"}'>Accessories</a>
            
        </li>
    </ul>
    
</li>
        <li class="js-nav-menu single-link" data-m='{"cT":"Container","id":"c9c2c1c9c3m1r1a1","sN":9,"aN":"c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_21" class="js-subm-uhf-nav-link" href="" data-m='{"id":"n1c9c2c1c9c3m1r1a1","sN":1,"aN":"c9c2c1c9c3m1r1a1"}'>Entertainment</a>
            
        </li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c10c2c1c9c3m1r1a1","sN":10,"aN":"c2c1c9c3m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_22-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c10c2c1c9c3m1r1a1","sN":1,"aN":"c10c2c1c9c3m1r1a1"}'>Business</span>
    <button id="uhf-navbtn-shellmenu_22-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c10c2c1c9c3m1r1a1","sN":2,"aN":"c10c2c1c9c3m1r1a1"}'>Business</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_22-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_Microsoft_Cloud_cont","cT":"Container","id":"c3c10c2c1c9c3m1r1a1","sN":3,"aN":"c10c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_23" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/microsoft-cloud" data-m='{"cN":"GlobalNav_More_Business_Microsoft_Cloud_nav","id":"n1c3c10c2c1c9c3m1r1a1","sN":1,"aN":"c3c10c2c1c9c3m1r1a1"}'>Microsoft Cloud</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_Microsoft Security_cont","cT":"Container","id":"c4c10c2c1c9c3m1r1a1","sN":4,"aN":"c10c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_24" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/security" data-m='{"cN":"GlobalNav_More_Business_Microsoft Security_nav","id":"n1c4c10c2c1c9c3m1r1a1","sN":1,"aN":"c4c10c2c1c9c3m1r1a1"}'>Microsoft Security</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_Azure_cont","cT":"Container","id":"c5c10c2c1c9c3m1r1a1","sN":5,"aN":"c10c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_25" class="js-subm-uhf-nav-link" href="https://azure.microsoft.com/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_Azure_nav","id":"n1c5c10c2c1c9c3m1r1a1","sN":1,"aN":"c5c10c2c1c9c3m1r1a1"}'>Azure</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_MicrosoftDynamics365_cont","cT":"Container","id":"c6c10c2c1c9c3m1r1a1","sN":6,"aN":"c10c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_26" class="js-subm-uhf-nav-link" href="https://dynamics.microsoft.com/" data-m='{"cN":"GlobalNav_More_Business_MicrosoftDynamics365_nav","id":"n1c6c10c2c1c9c3m1r1a1","sN":1,"aN":"c6c10c2c1c9c3m1r1a1"}'>Dynamics 365</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_Microsoft365forbusiness_cont","cT":"Container","id":"c7c10c2c1c9c3m1r1a1","sN":7,"aN":"c10c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_27" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/microsoft-365/business" data-m='{"cN":"GlobalNav_More_Business_Microsoft365forbusiness_nav","id":"n1c7c10c2c1c9c3m1r1a1","sN":1,"aN":"c7c10c2c1c9c3m1r1a1"}'>Microsoft 365 for business</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_MicrosoftIndustry_cont","cT":"Container","id":"c8c10c2c1c9c3m1r1a1","sN":8,"aN":"c10c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_28" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/industry" data-m='{"cN":"GlobalNav_More_Business_MicrosoftIndustry_nav","id":"n1c8c10c2c1c9c3m1r1a1","sN":1,"aN":"c8c10c2c1c9c3m1r1a1"}'>Microsoft Industry</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_MicrosoftPowerPlatform_cont","cT":"Container","id":"c9c10c2c1c9c3m1r1a1","sN":9,"aN":"c10c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_29" class="js-subm-uhf-nav-link" href="https://powerplatform.microsoft.com/" data-m='{"cN":"GlobalNav_More_Business_MicrosoftPowerPlatform_nav","id":"n1c9c10c2c1c9c3m1r1a1","sN":1,"aN":"c9c10c2c1c9c3m1r1a1"}'>Microsoft Power Platform</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Business_Windows365_cont","cT":"Container","id":"c10c10c2c1c9c3m1r1a1","sN":10,"aN":"c10c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_30" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/windows-365" data-m='{"cN":"GlobalNav_More_Business_Windows365_nav","id":"n1c10c10c2c1c9c3m1r1a1","sN":1,"aN":"c10c10c2c1c9c3m1r1a1"}'>Windows 365</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c11c2c1c9c3m1r1a1","sN":11,"aN":"c2c1c9c3m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_31-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c11c2c1c9c3m1r1a1","sN":1,"aN":"c11c2c1c9c3m1r1a1"}'>Developer &amp; IT  </span>
    <button id="uhf-navbtn-shellmenu_31-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c11c2c1c9c3m1r1a1","sN":2,"aN":"c11c2c1c9c3m1r1a1"}'>Developer &amp; IT  </button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_31-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_DeveloperCenter_cont","cT":"Container","id":"c3c11c2c1c9c3m1r1a1","sN":3,"aN":"c11c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_32" class="js-subm-uhf-nav-link" href="https://developer.microsoft.com/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_DeveloperCenter_nav","id":"n1c3c11c2c1c9c3m1r1a1","sN":1,"aN":"c3c11c2c1c9c3m1r1a1"}'>Developer Center</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_Documentation_cont","cT":"Container","id":"c4c11c2c1c9c3m1r1a1","sN":4,"aN":"c11c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_33" class="js-subm-uhf-nav-link" href="https://learn.microsoft.com/docs/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_Documentation_nav","id":"n1c4c11c2c1c9c3m1r1a1","sN":1,"aN":"c4c11c2c1c9c3m1r1a1"}'>Documentation</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_MicrosoftLearn_cont","cT":"Container","id":"c5c11c2c1c9c3m1r1a1","sN":5,"aN":"c11c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_34" class="js-subm-uhf-nav-link" href="https://learn.microsoft.com/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_MicrosoftLearn_nav","id":"n1c5c11c2c1c9c3m1r1a1","sN":1,"aN":"c5c11c2c1c9c3m1r1a1"}'>Microsoft Learn</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_MicrosoftTechCommunity_cont","cT":"Container","id":"c6c11c2c1c9c3m1r1a1","sN":6,"aN":"c11c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_35" class="js-subm-uhf-nav-link" href="https://techcommunity.microsoft.com/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_MicrosoftTechCommunity_nav","id":"n1c6c11c2c1c9c3m1r1a1","sN":1,"aN":"c6c11c2c1c9c3m1r1a1"}'>Microsoft Tech Community</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_AzureMarketplace_cont","cT":"Container","id":"c7c11c2c1c9c3m1r1a1","sN":7,"aN":"c11c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_36" class="js-subm-uhf-nav-link" href="https://azuremarketplace.microsoft.com/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_AzureMarketplace_nav","id":"n1c7c11c2c1c9c3m1r1a1","sN":1,"aN":"c7c11c2c1c9c3m1r1a1"}'>Azure Marketplace</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_AppSource_cont","cT":"Container","id":"c8c11c2c1c9c3m1r1a1","sN":8,"aN":"c11c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_37" class="js-subm-uhf-nav-link" href="https://appsource.microsoft.com/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_AppSource_nav","id":"n1c8c11c2c1c9c3m1r1a1","sN":1,"aN":"c8c11c2c1c9c3m1r1a1"}'>AppSource</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_DeveloperAndIT_VisualStudio_cont","cT":"Container","id":"c9c11c2c1c9c3m1r1a1","sN":9,"aN":"c11c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_38" class="js-subm-uhf-nav-link" href="https://visualstudio.microsoft.com/" data-m='{"cN":"GlobalNav_More_DeveloperAndIT_VisualStudio_nav","id":"n1c9c11c2c1c9c3m1r1a1","sN":1,"aN":"c9c11c2c1c9c3m1r1a1"}'>Visual Studio</a>
            
        </li>
    </ul>
    
</li>
<li class="f-sub-menu js-nav-menu nested-menu" data-m='{"cT":"Container","id":"c12c2c1c9c3m1r1a1","sN":12,"aN":"c2c1c9c3m1r1a1"}'>

    <span id="uhf-navspn-shellmenu_39-span" style="display:none"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn1c12c2c1c9c3m1r1a1","sN":1,"aN":"c12c2c1c9c3m1r1a1"}'>Other</span>
    <button id="uhf-navbtn-shellmenu_39-button" type="button"   f-multi-parent="true" aria-expanded="false" data-m='{"id":"nn2c12c2c1c9c3m1r1a1","sN":2,"aN":"c12c2c1c9c3m1r1a1"}'>Other</button>
    <ul aria-hidden="true" aria-labelledby="uhf-navspn-shellmenu_39-span">
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Other_FreeDownloadsAndSecurity_cont","cT":"Container","id":"c3c12c2c1c9c3m1r1a1","sN":3,"aN":"c12c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_40" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/download" data-m='{"cN":"GlobalNav_More_Other_FreeDownloadsAndSecurity_nav","id":"n1c3c12c2c1c9c3m1r1a1","sN":1,"aN":"c3c12c2c1c9c3m1r1a1"}'>Free downloads &amp; security</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Other_Education_cont","cT":"Container","id":"c4c12c2c1c9c3m1r1a1","sN":4,"aN":"c12c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_41" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/education?icid=CNavMSCOML0_Studentsandeducation" data-m='{"cN":"GlobalNav_More_Other_Education_nav","id":"n1c4c12c2c1c9c3m1r1a1","sN":1,"aN":"c4c12c2c1c9c3m1r1a1"}'>Education</a>
            
        </li>
        <li class="js-nav-menu single-link" data-m='{"cN":"More_Other_GiftCards_cont","cT":"Container","id":"c5c12c2c1c9c3m1r1a1","sN":5,"aN":"c12c2c1c9c3m1r1a1"}'>
            <a id="shellmenu_42" class="js-subm-uhf-nav-link" href="https://www.microsoft.com/en-us/store/b/gift-cards" data-m='{"cN":"GlobalNav_More_Other_GiftCards_nav","id":"n1c5c12c2c1c9c3m1r1a1","sN":1,"aN":"c5c12c2c1c9c3m1r1a1"}'>Gift cards</a>
            
        </li>
    </ul>
    
</li>
                                                            <li class="f-multi-column-info">
                                    <a data-m='{"id":"n13c2c1c9c3m1r1a1","sN":13,"aN":"c2c1c9c3m1r1a1"}' href="https://www.microsoft.com/en-us/sitemap.aspx" aria-label="" class="c-glyph">View Sitemap</a>
                                </li>
                            
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
</div>
                            <form class="c-search" autocomplete="off" id="searchForm" name="searchForm" role="search" action="https://www.microsoft.com/en-us/search/result.aspx" method="GET" data-seAutoSuggest='{"queryParams":{"market":"en-ww","clientId":"7F27B536-CF6B-4C65-8638-A0F8CBDFCA65","sources":"Microsoft-Terms,Iris-Products,DCatAll-Products","filter":"ExcludeDCatProducts:DCatDevices-Products,DCatSoftware-Products,DCatBundles-Products+ClientType:StoreWeb","counts":"5,1,5"},"familyNames":{"Apps":"App","Books":"Book","Bundles":"Bundle","Devices":"Device","Fees":"Fee","Games":"Game","MusicAlbums":"Album","MusicTracks":"Song","MusicVideos":"Video","MusicArtists":"Artist","OperatingSystem":"Operating System","Software":"Software","Movies":"Movie","TV":"TV","CSV":"Gift Card","VideoActor":"Actor"}}' data-seautosuggestapi="https://www.microsoft.com/msstoreapiprod/api/autosuggest" data-m='{"cN":"GlobalNav_Search_cont","cT":"Container","id":"c3c1c9c3m1r1a1","sN":3,"aN":"c1c9c3m1r1a1"}' aria-expanded="false">
                                <input  id="cli_shellHeaderSearchInput" aria-label="Search Expanded" aria-autocomplete="list" aria-expanded="false" aria-controls="universal-header-search-auto-suggest-transparent" aria-owns="universal-header-search-auto-suggest-ul" type="search" name="q" role="combobox" placeholder="Search Microsoft.com" data-m='{"cN":"SearchBox_nav","id":"n1c3c1c9c3m1r1a1","sN":1,"aN":"c3c1c9c3m1r1a1"}' data-toggle="tooltip" data-placement="right" title="Search Microsoft.com" />
                                    <input type="hidden" name="form" value="apps" data-m='{"cN":"HiddenInput_nav","id":"n2c3c1c9c3m1r1a1","sN":2,"aN":"c3c1c9c3m1r1a1"}' />
                                    <button id="search" aria-label="Search Microsoft.com" class="c-glyph" data-m='{"cN":"Search_nav","id":"n3c3c1c9c3m1r1a1","sN":3,"aN":"c3c1c9c3m1r1a1"}' data-bi-mto="true" aria-expanded="false" disabled="disabled">
                                        <span role="presentation">Search</span>
                                        <span role="tooltip" class="c-uhf-tooltip c-uhf-search-tooltip">Search Microsoft.com</span>
                                    </button>
                                <div class="m-auto-suggest" id="universal-header-search-auto-suggest-transparent" role="group">
                                    <ul class="c-menu" id="universal-header-search-auto-suggest-ul" aria-label="Search Suggestions" aria-hidden="true" data-bi-dnt="true" data-bi-mto="true" data-js-auto-suggest-position="default" role="listbox" data-tel="jsll" data-m='{"cN":"search suggestions_cont","cT":"Container","id":"c4c3c1c9c3m1r1a1","sN":4,"aN":"c3c1c9c3m1r1a1"}'></ul>
                                    <ul class="c-menu f-auto-suggest-no-results" aria-hidden="true" data-js-auto-suggest-postion="default" data-js-auto-suggest-position="default" role="listbox">
                                        <li class="c-menu-item"> <span tabindex="-1">No results</span></li>
                                    </ul>
                                </div>
                                
                            </form>
                        <button data-m='{"cN":"cancel-search","pid":"Cancel Search","id":"nn4c1c9c3m1r1a1","sN":4,"aN":"c1c9c3m1r1a1"}' id="cancel-search" class="cancel-search" aria-label="Cancel Search">
                            <span>Cancel</span>
                        </button>
                        <div id="meControl" class="c-me"  data-signinsettings='{"containerId":"meControl","enabled":true,"headerHeight":48,"debug":false,"extensibleLinks":[{"string":"For home","url":"https://www.office.com/?auth=1","id":"global-office-account-personal"},{"string":"Work, school or university","url":"https://www.office.com/?auth=2","id":"global-office-account-commercial"}],"userData":{"idp":"msa","firstName":"","lastName":"","memberName":"","cid":"","authenticatedState":"3"},"rpData":{"preferredIdp":"msa","msaInfo":{"signInUrl":"","signOutUrl":"","meUrl":"https://login.live.com/me.srf?wa=wsignin1.0"},"aadInfo":{"signOutUrl":"","appId":"","siteUrl":"","blockMsaFed":true}}}' data-m='{"cN":"GlobalNav_Account_cont","cT":"Container","id":"c5c1c9c3m1r1a1","sN":5,"aN":"c1c9c3m1r1a1"}'>
                            <div class="msame_Header">
                                <div class="msame_Header_name st_msame_placeholder">Sign in</div>
                            </div>
                            
                        </div>
                
            </div>
        </div>
        
        
    </div>
    
</header>




    </div>
        </div>

    </div>
  <div class='meControl-configInfo' data-isenabled='true' data-preferredidp='aad' data-signinurl='/rpsauth/v2/account/aad/signin?ruoverride=https%3A%2F%2Fwww.office.com%3Fauthtypeparamname%3Dauth' data-msasignouturl='/rpsauth/v2/account/msa/signout' data-aadsignouturl='/rpsauth/v2/account/aad/signout' data-convergedstack='false' data-accountconstraint='0' data-apigeneration='GEN1' data-silentauthrequirereload='false' data-silentauthaction='none'></div> <div class='userInfo-config' data-userInfoUrl='/rpsauth/v2/api/account/aad/userinfo' data-userInfoTimeoutMS='1000' data-retryDelayMS='2000' data-maxRetryAttempt='3'></div> <script src="/etc.clientlibs/microsoft/components/content/universalheader/v1/universalheader/clientlibs/site.min.ACSHASH4a2c06fd33b93cde144b578363a889af.js"></script> </div> <div class="layout-container responsivegrid aem-GridColumn aem-GridColumn--default--12" data-component-id="28134f1ee1370eee417bc52d1ed0a717"> <main class="microsoft-template-layout-container" tabindex="-1"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 "> <div class="responsivegrid aem-GridColumn aem-GridColumn--default--12"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 "> <div class="targeting-container aem-GridColumn aem-GridColumn--default--12" data-component-id="3a796505b6c04fa385e30bdb1b3679f7">  </div> <div class="targeting-container aem-GridColumn aem-GridColumn--default--12" data-component-id="3a796505b6c04fa385e30bdb1b3679f7">  <div class="feature" data-component-id="d6a4227ba17e2a4594392d6d0fe450de"> <section data-mount="m365-feature" data-image-first="false" data-oc="ocf626" id="feature-oc387eee1"> <div class="card container-fluid w-auto px-0 mx-0 "> <div class="row no-gutters material-surface justify-content-center grid-md-feature px-md-0 mx-md-0 w-auto"> <div class="d-flex col-md grid-feature-item-1"> <div class="card-body p-4 p-md-5"> <div class="mb-0 "> </div> <div> <section> </section> </div> <h1 class="h1 text-outlook "> Microsoft Outlook </h1> <div class="mb-3 "> <div data-oc-token-text> <span class="h3 mb-0">Connect, organize, and get things done with free personal email and calendar.</span> </div> </div> <div class=" link-group link-group-col-1 link-group-col-sm-2 link-group-col-xl-3"> <div> <input type="hidden" value="https://go.microsoft.com/fwlink/p/?linkid=2214389" id="modal-redirection-URL"/> <input type="hidden" value="365" id="modal-cookie-expiration"/> <input type="hidden" value="#mobilehero1" id="modal-redirect-id"/> <script src="/etc.clientlibs/onecloud/clientlibs/clientlib-link-custom-action-types/modal-redirect.min.ACSHASH6e730334e2c795989cc7dff0c16e7fb7.js"></script> <a data-bi-cn="Sign in" data-bi-ecn="Sign in" data-bi-ct="button" data-bi-pa="body" data-bi-bhvr="100" data-bi-tags="{&#34;BiLinkName&#34;:&#34;SignIn&#34;}" class="btn btn-outlook oc-modalredirect-custom-action " data-target="#mobilehero1" aria-label="Sign in." target="_self" href="#mobilehero1"> <span>Sign in</span> </a> </div> <div> <a data-bi-cn="Create free account" data-bi-ecn="Create free account" data-bi-ct="button" data-bi-pa="body" data-bi-bhvr="210" data-bi-tags="{&#34;BiLinkName&#34;:&#34;CreateFreeAccount&#34;}" class="btn btn-outline-primary-white " data-target="https://go.microsoft.com/fwlink/p/?linkid=2125440&amp;culture=en-us&amp;country=ww" aria-label="Create a free Microsoft Outlook account" data-regenerate-fwlink="true" target="_self" href="https://go.microsoft.com/fwlink/p/?linkid=2125440&culture=en-us&country=ww"> <span>Create free account</span> </a> </div> </div> <div class=" link-group mt-4"> <a data-bi-cn="Try premium" data-bi-ecn="Try premium" data-bi-ct="cta" data-bi-pa="body" data-bi-bhvr="81" data-bi-tags="{&#34;BiLinkName&#34;:&#34;TryPremium&#34;}" class="cta cta font-weight-semibold " data-target="https://www.microsoft.com/en/microsoft-365/outlook/outlook-personal-email-plans" aria-label="Try Microsoft Outlook premium" target="_self" href="https://www.microsoft.com/en/microsoft-365/outlook/outlook-personal-email-plans"> <span>Try premium</span> </a> </div> <div class="text-center text-md-left"> </div> </div> </div> <div class="col-md grid-feature-item-2"> <img class="img-object-cover card-img lazyload blur-up lazypreload img-object-cover img-object-cover img-object-pos-0-50 " alt="A tablet and a phone showing Outlook inbox on the screens" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/hero_image@2x_RE4rxpr?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=960&amp;qlt=90&amp;fmt=png-alpha&amp;fit=constrain" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/hero_image@2x_RE4rxpr?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=960&amp;qlt=90&amp;fmt=png-alpha&amp;fit=constrain"/> </div> </div> </div> </section> </div> <div class="hero-cta" data-component-id="070d0c33c2bcf3b0c9262cfda5d6ed71"> <section data-oc="oc5ff4" id="hero-cta-oc5ff131"> <div class="nav-bar nav-bar-expand-lg bg-light border-bottom sticky-transition nav-bar-show-stuck" data-mount="m365-nav-bar" data-direction="top"> <div class="container sticky-show-stuck"> <nav class="m365-horizontal-nav-container nav-container py-2 d-flex align-items-center flex-fill justify-content-lg-between bg-light" aria-label="Microsoft Outlook"> <div class="sticky-show-stuck"> <div class="d-none d-lg-block"> <h2 class="h5 " aria-live="polite"> Microsoft Outlook </h2> </div> </div> <div class="sticky-show-stuck ml-lg-auto" aria-live="polite"> <ul class="nav d-none d-lg-flex align-items-center"> <li class="nav-item mx-0 my-2"> <div class="link-group nav-link mt-0 py-0 "> <a data-bi-cn="Sign in" data-bi-ecn="Sign in" data-bi-ct="cta" data-bi-pa="body" data-bi-bhvr="100" data-bi-tags="{&#34;BiLinkName&#34;:&#34;SignIn&#34;}" class="cta cta font-weight-semibold " data-target="https://go.microsoft.com/fwlink/p/?linkid=2092832&amp;culture=en-us&amp;country=ww" aria-label="Sign in." target="_blank" data-regenerate-fwlink="true" href="https://go.microsoft.com/fwlink/p/?linkid=2092832&culture=en-us&country=ww"> <span>Sign in</span> </a> </div> </li> <li class="nav-item mx-0 my-2"> <div class="link-group nav-link my-0 py-0 "> <a data-bi-cn="Try premium" data-bi-ecn="Try premium" data-bi-ct="button" data-bi-pa="body" data-bi-bhvr="81" data-bi-tags="{&#34;BiLinkName&#34;:&#34;Trypremium&#34;}" class="btn btn-outline-primary-white " data-target="https://www.microsoft.com/en/microsoft-365/outlook/outlook-personal-email-plans" aria-label="Try Microsoft Outlook premium" target="_self" href="https://www.microsoft.com/en/microsoft-365/outlook/outlook-personal-email-plans"> <span>Try premium</span> </a> </div> </li> <li class="nav-item mx-0 my-2"> <div class="link-group nav-link my-0 py-0 "> <a data-bi-cn="Create free account" data-bi-ecn="Create free account" data-bi-ct="button" data-bi-pa="body" data-bi-bhvr="232" data-bi-tags="{&#34;BiLinkName&#34;:&#34;CreateFreeAccount&#34;}" class="btn btn-primary " data-target="#mobilehero1" aria-label="Create a free Microsoft Outlook account" target="_self" href="#mobilehero1"> <span>Create free account</span> </a> </div> </li> </ul> </div> <div class="dropdown sticky-show-stuck" aria-live="polite"> <a href="javascript:void(0)" class=" nav-link d-lg-none ml-4 font-weight-normal dropdown-toggle" id="x4e106c2fbf9a4d5793c8e824dc4bca32" data-mount="m365-dropdown" aria-expanded="false" aria-controls="xff2f00865fe5485b9775eea447b04c37">Microsoft Outlook</a> <ul class="dropdown-menu d-lg-none bg-light" id="xff2f00865fe5485b9775eea447b04c37" aria-labelledby="x4e106c2fbf9a4d5793c8e824dc4bca32"> <li> <div class="link-group dropdown-item my-0 py-0 font-weight-normal "> <a data-bi-cn="Sign in" data-bi-ecn="Sign in" data-bi-ct="cta" data-bi-pa="body" data-bi-bhvr="100" data-bi-tags="{&#34;BiLinkName&#34;:&#34;SignIn&#34;}" class="py-3 px-4 m-0 bg-transparent text-dark font-weight-semibold text-dark" data-target="https://go.microsoft.com/fwlink/p/?linkid=2092832&amp;culture=en-us&amp;country=ww" data-regenerate-fwlink="true" aria-label="Sign in." target="_blank" href="https://go.microsoft.com/fwlink/p/?linkid=2092832&culture=en-us&country=ww"> <span>Sign in</span> </a> </div> </li> <li> <div class="link-group dropdown-item my-0 py-0 font-weight-normal "> <a data-bi-cn="Try premium" data-bi-ecn="Try premium" data-bi-ct="button" data-bi-pa="body" data-bi-bhvr="81" data-bi-tags="{&#34;BiLinkName&#34;:&#34;Trypremium&#34;}" class="py-3 px-4 m-0 bg-transparent font-weight-semibold" data-target="https://www.microsoft.com/en/microsoft-365/outlook/outlook-personal-email-plans" aria-label="Try Microsoft Outlook premium" target="_self" href="https://www.microsoft.com/en/microsoft-365/outlook/outlook-personal-email-plans"> <span>Try premium</span> </a> </div> </li> <li> <div class="link-group dropdown-item my-0 py-0 font-weight-normal "> <a data-bi-cn="Create free account" data-bi-ecn="Create free account" data-bi-ct="button" data-bi-pa="body" data-bi-bhvr="232" data-bi-tags="{&#34;BiLinkName&#34;:&#34;CreateFreeAccount&#34;}" class="py-3 px-4 m-0 bg-transparent font-weight-semibold" data-target="#mobilehero1" aria-label="Create a free Microsoft Outlook account" target="_self" href="#mobilehero1"> <span>Create free account</span> </a> </div> </li> </ul> </div> </nav> </div> </div> </section></div> <div class="layout-container responsivegrid" data-component-id="51e927945f39700e952adb9bd3dc97e7"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 grid-image-layout-container-uid4bec heading-bg-color-layout-container-uid4bec" data-automation-test-id="layout-container-uid4bec"> <style data-automation-test-id="headingColor-layout-container-uid4bec">
                    .heading-bg-color-layout-container-uid4bec{
                         background-color:  !important;
                    }
          </style> <div class="container" id="layout-container-uid4bec" data-componentName="layout-container-uid4bec"> <div class="modal-component container responsivegrid aem-GridColumn aem-GridColumn--default--12" data-component-id="cb1cb950010a80ddf6598f1c812b62ad"> <link rel="stylesheet" href="/etc.clientlibs/microsoft/components/content/sites-modal-component/v1/sites-modal-component/clientlibs/site.min.ACSHASH6f083a779b1f1f71387faa38dfa66f12.css" type="text/css"> <link rel="stylesheet" href="/etc.clientlibs/microsoft/components/content/modal-component/v1/modal-component/clientlibs/site.min.ACSHASH6f083a779b1f1f71387faa38dfa66f12.css" type="text/css"> <div data-mount="modal" class="modal fade pause-onhide" id="mobilehero1" tabindex="-1" role="dialog" aria-label="mobilehero1" aria-modal="true"> <div class="modal-dialog modal-lg modal-dialog-scrollable" data-automation-test-id="modal-dialog-"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close " aria-label="Close dialog window" title="Close" data-dismiss="modal" data-automation-test-id="modal-button-"></button> </div> <div class="modal-body " data-automation-test-id="modal-body-"> <div data-automation-test-id="modal-heading-"> </div> <div class="heading aem-GridColumn aem-GridColumn--default--12" data-component-id="9b992e252846bf14b532f40bd58c2fbf"> <section data-oc="oce31b" id="heading-oce31b"> <h2 class="text-center "> Download the free Outlook experience designed for your phone </h2> </section> </div> <div class="image aem-GridColumn aem-GridColumn--default--12" data-component-id="9b002e252846bf14b532f40bd58c2fca"> <link rel="stylesheet" href="/etc.clientlibs/onecloud/components/content/image/v1/image/clientlibs.min.ACSHASH4402231c6c651d105bb28a0781aa644e.css" type="text/css"> <img class="img-fluid mx-auto d-block lazyload blur-up " alt="A tablet and a phone showing Outlook inbox on the screens" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/RE51fSR?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;qlt=85, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/RE51fSR?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;qlt=85 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/RE51fSR?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;qlt=85" data-oc="oc58a0" id="image-oc58a0"/> </div> <div class="feature aem-GridColumn aem-GridColumn--default--12" data-component-id="d6a4227ba17e2a4594392d6d0fe450de"> <section data-mount="m365-feature" data-image-first="false" data-oc="oce4cc" id="feature-oce4cc"> <div class="card mx-ng mx-md-0 "> <div class="row no-gutters style-utility-760b7c46-9169-45af-90cc-e589a652075c-oc-aem-bg-color-picker oc-aem-feature-bg-color-picker-feature-oce4cc material-surface text-center"> <style>
                    .oc-aem-feature-bg-color-picker-feature-oce4cc {
                        background-color: #fff!important;;
                    }
                </style> <div class="d-flex col-md-6"> <div class="card-body p-4 p-md-5"> <div class="mb-0 "> </div> <div class="mb-3 "> </div> <div class=" link-group "> <a data-bi-cn="Download" data-bi-ecn="Download" data-bi-ct="button" data-bi-pa="body" data-bi-bhvr="41" data-bi-tags="{&#34;BiLinkName&#34;:&#34;Download1&#34;}" class="btn btn-primary " data-target="https://www.microsoft.com/en/microsoft-365/outlook/mobile-app" aria-label="Download Microsoft Outlook" target="_self" href="https://www.microsoft.com/en/microsoft-365/outlook/mobile-app"> <span>Download</span> </a> </div> <div class=" link-group "> <a data-bi-cn="Sign in" data-bi-ecn="Sign in" data-bi-ct="cta" data-bi-pa="body" data-bi-bhvr="100" data-bi-tags="{&#34;BiLinkName&#34;:&#34;SignIn&#34;}" class="cta cta font-weight-semibold " data-target="https://go.microsoft.com/fwlink/p/?linkid=2105311&amp;culture=en-us&amp;country=ww" aria-label="Sign in to Microsoft Outlook" target="_self" data-regenerate-fwlink="true" href="https://go.microsoft.com/fwlink/p/?linkid=2105311&culture=en-us&country=ww"> <span>Sign in</span> </a> </div> <div class="text-center text-md-left"> </div> </div> </div> </div> </div> </section> </div> </div> </div> </div> </div> <script src="/etc.clientlibs/microsoft/components/content/sites-modal-component/v1/sites-modal-component/clientlibs/site.min.ACSHASHd41d8cd98f00b204e9800998ecf8427e.js"></script> <script src="/etc.clientlibs/microsoft/components/content/modal-component/v1/modal-component/clientlibs/site.min.ACSHASH1d54ef912663f344cfa7b55b016dd0c7.js"></script> </div> </div> </div></div>  </div> <div class="targeting-container aem-GridColumn aem-GridColumn--default--12" data-component-id="3a796505b6c04fa385e30bdb1b3679f7">  </div> <div class="layout-container responsivegrid py-5 material-color-primary material-surface material-lg-surface aem-GridColumn aem-GridColumn--default--12" data-component-id="51e927945f39700e952adb9bd3dc97e7"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 grid-image-layout-container-uidc128a material-color-primary heading-bg-color-layout-container-uidc128a" data-automation-test-id="layout-container-uidc128a"> <style data-automation-test-id="headingColor-layout-container-uidc128a">
                    .heading-bg-color-layout-container-uidc128a{
                         background-color:  !important;
                    }
          </style> <div class="container" id="layout-container-uidc128a" data-componentName="layout-container-uidc128a"> <div class="heading aem-GridColumn aem-GridColumn--default--12" data-component-id="9b992e252846bf14b532f40bd58c2fbf"> <section data-oc="ocf553" id="heading-ocf553"> <h2 class="mx-4 h4 text-center "> Everything you need to be your most productive and connected self–at home, on the go, and everywhere in between </h2> </section> </div> </div> </div></div> <div class="targeting-container aem-GridColumn aem-GridColumn--default--12" data-component-id="3a796505b6c04fa385e30bdb1b3679f7">  <div class="heading" data-component-id="9b992e252846bf14b532f40bd58c2fbf"> <section data-oc="oc66c6" id="heading-oc66c6"> <h2 class="text-center "> Download the free Outlook app for your phone </h2> </section> </div> <div class="image" data-component-id="9b002e252846bf14b532f40bd58c2fca"> <img class="img-fluid d-block mx-auto lazyload blur-up " alt="A tablet and a phone showing Outlook inbox on the screens" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/RE4rD19?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;qlt=85, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/RE4rD19?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;qlt=85 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/RE4rD19?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;qlt=85" data-oc="oc2115" id="image-oc2115"/> </div> <div class="feature" data-component-id="d6a4227ba17e2a4594392d6d0fe450de"> <section data-mount="m365-feature" data-image-first="false" data-oc="oc6144" id="feature-oc6144"> <div class="card mx-ng mx-md-0 "> <div class="row no-gutters style-utility-430e548f-5cf5-4143-878a-7709b892fafb-oc-aem-bg-color-picker oc-aem-feature-bg-color-picker-feature-oc6144 material-surface text-center"> <style>
                    .oc-aem-feature-bg-color-picker-feature-oc6144 {
                        background-color: #fff!important;;
                    }
                </style> <div class="d-flex col-md-6"> <div class="card-body p-4 p-md-5"> <div class="mb-0 "> </div> <div class="mb-3 "> </div> <div class=" link-group "> <a data-bi-cn="Download now" data-bi-ecn="Download now" data-bi-ct="button" data-bi-pa="body" data-bi-bhvr="230" data-bi-tags="{&#34;BiLinkName&#34;:&#34;DownloadNow&#34;}" class="btn btn-primary " data-target="https://www.microsoft.com/en/microsoft-365/outlook/mobile-app" aria-label="Download now" target="_self" href="https://www.microsoft.com/en/microsoft-365/outlook/mobile-app"> <span>Download now</span> </a> </div> <div class="text-center text-md-left"> </div> </div> </div> </div> </div> </section> </div>  </div> <div class="targeting-container aem-GridColumn aem-GridColumn--default--12" data-component-id="3a796505b6c04fa385e30bdb1b3679f7">  </div> <div class="highlight aem-GridColumn aem-GridColumn--default--12" data-component-id="5e1ee03032262058e61848c44cc34b77"> <section data-oc="oc23c8" id="highlight-oc23c9"> <div class="card-img-overlay "> <div class="card-background my-0"> <picture class="h-100 w-100"> <source media="(min-width: 1400px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/outlook_blade2_RE4s5QT?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 1084px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/outlook_blade2_RE4s5QT?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/outlook_blade2_RE4s5QT?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=3840&amp;qlt=85&amp;fit=constrain 2x"/> <source media="(min-width: 860px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/outlook_blade2_RE4s5QT?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 540px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image01375x275_RE4sb3t?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image01375x275_RE4sb3t?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x"/> <img class=" lazyload blur-up lazypreload card-img w-100 " alt="A tablet and a phone showing Outlook calendar on the screens." data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image01375x275_RE4sb3t?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image01375x275_RE4sb3t?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image01375x275_RE4sb3t?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> </picture> </div> <div class="card-foreground justify-content-end "> <div class="container "> <div class="d-flex mt-md-n5 my-lg-5 justify-content-end"> <div class="w-100 w-lg-col-4 "> <div class="card py-5 px-md-5 depth-lg-none bg-lg-transparent-text-dark material-md-card "> <div class="card-body " data-highlight-compname="Highlight (OneCloud) , Card horizontal alignment of justify-content-end, Card size w-lg-col-4, Card transparency set to true"> <div class="mb-0 "> </div> <h2 class="h2 "> Email and calendar, together in one place </h2> <div class="mb-4" data-oc-token-text> <p>Send, receive, and manage your email. Use Outlook’s built-in calendar to keep track of appointments and events.</p> </div> </div> </div> </div> </div> </div> </div> </div> <script src="/etc.clientlibs/onecloud/components/content/highlight/v1/highlight/clientlibs/site.min.ACSHASH14fd846874af3385d1933e362a28b18f.js"></script> </section></div> <div class="layout-container responsivegrid aem-GridColumn aem-GridColumn--default--12" data-component-id="51e927945f39700e952adb9bd3dc97e7"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 grid-image-layout-container-uid373b heading-bg-color-layout-container-uid373b" data-automation-test-id="layout-container-uid373b"> <style data-automation-test-id="headingColor-layout-container-uid373b">
                    .heading-bg-color-layout-container-uid373b{
                         background-color:  !important;
                    }
          </style> <div class="container" id="layout-container-uid373b" data-componentName="layout-container-uid373b"> </div> </div></div> <div class="layout-container responsivegrid pb-7 pt-7 material-surface material-lg-surface aem-GridColumn aem-GridColumn--default--12" data-component-id="51e927945f39700e952adb9bd3dc97e7"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 grid-image-layout-container-uid554 material-surface heading-bg-color-layout-container-uid554" data-automation-test-id="layout-container-uid554"> <style data-automation-test-id="headingColor-layout-container-uid554">
                    .heading-bg-color-layout-container-uid554{
                         background-color:  !important;
                    }
          </style> <div class="container" id="layout-container-uid554" data-componentName="layout-container-uid554"> <div class="heading aem-GridColumn aem-GridColumn--default--12" data-component-id="9b992e252846bf14b532f40bd58c2fbf"> <section data-oc="oc6d8a" id="heading-oc6d8a"> <h2 class="h2 text-center pb-5 "> Stay safe and connected with security you can trust </h2> </section> </div> <div class="layout-container responsivegrid aem-GridColumn aem-GridColumn--default--12" data-component-id="51e927945f39700e952adb9bd3dc97e9"> <div id="layout-container-uidfe59" data-componentName="layout-container-uidfe59" class="default " data-automation-test-id="picture-layout-container-uidfe59"> <div class="container"> <div class="row row-cols-1 row-cols-md-2 depth-0 default row-bg-color-layout-container-uidfe59" data-automation-test-id="mainContainer-layout-container-uidfe59"> <style data-automation-test-id="bgcolorPicker-layout-container-uidfe59">
                .row-bg-color-layout-container-uidfe59{
                    background-color:  !important;
                }
                
            </style> <div class="col text-md-left px-4 mb-4 mb-md-0 " data-automation-test-id="column-layout-container-uidfe59"> <div class="content-card-list aem-GridColumn aem-GridColumn--default--12" data-component-id="105a879b073976e6fcf80d896ff465cf"> <section> <div class="row row-cols-1" data-oc="oc258b" id="content-card-list-oc258b"> <div class="col "> <div class="card h-100 material-card text-center" data-oc="oc8faa" id="content-card-vertical-oc8faa"> <div class="card-body pt-3"> <h2 class="h2 pt-5"> Your data, controlled by you </h2> <div data-oc-token-text> <p>Outlook puts you in control of your privacy.</p> </div> </div> <div class="px-4"> <img class="card-img w-100 lazyload blur-up pt-3 " alt="Two adults and a child snuggle on a couch while looking at something on a laptop screen and smiling." data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Compare-module-image01x2_RE4s8qx?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=786&amp;hei=443&amp;qlt=85&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Compare-module-image01x2_RE4s8qx?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1572&amp;hei=886&amp;qlt=85&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Compare-module-image01x2_RE4s8qx?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=786&amp;hei=443&amp;qlt=85&amp;fit=constrain"/> </div> <div class="card-body pt-3 px-4"> <div data-oc="oc5aed" id="content-card-list-oc5aed"> <ul class="list-unstyled "> <li class=" d-flex mb-4"> <img class=" lazyload blur-up " alt width="48" height="48" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon01x2_RE4slnt?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon01x2_RE4slnt?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=96&amp;hei=96&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon01x2_RE4slnt?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> <div class="card ml-3" data-oc="oc65fb" id="content-card-horizontal-oc65fb"> <div class="card-body"> <p style="text-align: left;">We help you take charge with easy-to-use tools and clear choices.</p> </div> </div> </li> <li class=" d-flex mb-4"> <img class=" lazyload blur-up " alt width="48" height="48" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon02x2_RE4s5QM?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon02x2_RE4s5QM?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=96&amp;hei=96&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon02x2_RE4s5QM?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> <div class="card ml-3" data-oc="oc43b6" id="content-card-horizontal-oc43b6"> <div class="card-body"> <p style="text-align: left;">We’re transparent about data collection and use so you can make informed decisions.</p> </div> </div> </li> <li class=" d-flex mb-4"> <img class=" lazyload blur-up " alt width="48" height="48" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon03x2_RE4slo2?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon03x2_RE4slo2?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=96&amp;hei=96&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon03x2_RE4slo2?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> <div class="card ml-3" data-oc="oc6dac" id="content-card-horizontal-oc6dac"> <div class="card-body"> <p style="text-align: left;">We don’t use your email, calendar, or other personal content to target ads to you.</p> </div> </div> </li> <li class=" d-flex mb-4"> <img class=" lazyload blur-up " alt width="48" height="48" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon04x2_RE4s8qA?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon04x2_RE4s8qA?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=96&amp;hei=96&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon04x2_RE4s8qA?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> <div class="card ml-3" data-oc="ocd168" id="content-card-horizontal-ocd168"> <div class="card-body"> <p style="text-align: left;">When we collect data, we use it to benefit you and make your experience better.</p> </div> </div> </li> </ul> </div> </div> <div class="card-footer px-4 pb-4"> </div> </div> </div> </div> </section> </div> </div> <div class="col text-md-left px-4 " data-automation-test-id="column-layout-container-uidfe59"> <div class="content-card-list aem-GridColumn aem-GridColumn--default--12" data-component-id="105a879b073976e6fcf80d896ff465cf"> <section> <div class="row row-cols-1" data-oc="oc2473" id="content-card-list-oc2473"> <div class="col "> <div class="card h-100 material-card text-center" data-oc="oc4d5f" id="content-card-vertical-oc4d5f"> <div class="card-body pt-3"> <h2 class="h2 pt-5"> Backed by enterprise-grade security </h2> <div data-oc-token-text> <p>Outlook works around the clock to help protect your data.</p> </div> </div> <div class="px-4"> <img class="card-img w-100 lazyload blur-up pt-3 " alt="A person reading an email in Outlook on a laptop" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Compare-module-image02x2_RE4s5Rh?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=786&amp;hei=443&amp;qlt=85&amp;fit=constrain" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Compare-module-image02x2_RE4s5Rh?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=786&amp;hei=443&amp;qlt=85&amp;fit=constrain"/> </div> <div class="card-body pt-3 px-4"> <div data-oc="oc41f9" id="content-card-list-oc41f9"> <ul class="list-unstyled "> <li class=" d-flex mb-4"> <img class=" lazyload blur-up " alt width="48" height="48" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon05x2_RE4slo5?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon05x2_RE4slo5?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=96&amp;hei=96&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon05x2_RE4slo5?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> <div class="card ml-3" data-oc="oc4c11" id="content-card-horizontal-oc4c11"> <div class="card-body"> <p style="text-align: left;">Protection delivered by the same tools Microsoft uses for business customers.</p> </div> </div> </li> <li class=" d-flex mb-4"> <img class=" lazyload blur-up " alt width="48" height="48" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon06x2_RE4s5Rp?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon06x2_RE4s5Rp?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=96&amp;hei=96&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon06x2_RE4s5Rp?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> <div class="card ml-3" data-oc="oc69d4" id="content-card-horizontal-oc69d4"> <div class="card-body"> <p style="text-align: left;">Data encryption in your mailbox and after email is sent.</p> </div> </div> </li> <li class=" d-flex mb-4"> <img class=" lazyload blur-up " alt width="48" height="48" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon07x2_RE4s8qD?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon07x2_RE4s8qD?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=96&amp;hei=96&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon07x2_RE4s8qD?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> <div class="card ml-3" data-oc="oc8ebc" id="content-card-horizontal-oc8ebc"> <div class="card-body"> <p style="text-align: left;">Automatic deactivation of unsafe links containing phishing scams, viruses, or malware. (Premium)</p> </div> </div> </li> <li class=" d-flex mb-4"> <img class=" lazyload blur-up " alt width="48" height="48" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon081_RE4sb3e?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon081_RE4sb3e?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=96&amp;hei=96&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/icon081_RE4sb3e?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=48&amp;hei=48&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> <div class="card ml-3" data-oc="oc29a9" id="content-card-horizontal-oc29a9"> <div class="card-body"> <p style="text-align: left;">Ransomware detection and recovery for your important files in OneDrive. (Premium)</p> </div> </div> </li> </ul> </div> </div> <div class="card-footer px-4 pb-4"> </div> </div> </div> </div> </section> </div> </div> </div> </div> </div></div> </div> </div></div> <div class="layout-container responsivegrid pb-5 material-surface material-lg-surface aem-GridColumn aem-GridColumn--default--12" data-component-id="51e927945f39700e952adb9bd3dc97e7"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 grid-image-layout-container-uidf6f4 heading-bg-color-layout-container-uidf6f4" data-automation-test-id="layout-container-uidf6f4"> <style data-automation-test-id="headingColor-layout-container-uidf6f4">
                    .heading-bg-color-layout-container-uidf6f4{
                         background-color:  !important;
                    }
          </style> <div class="container" id="layout-container-uidf6f4" data-componentName="layout-container-uidf6f4"> </div> </div></div> <div class="highlight aem-GridColumn aem-GridColumn--default--12" data-component-id="5e1ee03032262058e61848c44cc34b77"> <section data-oc="oc23c8" id="highlight-oc23c"> <div class="card-img-overlay "> <div class="card-background my-0"> <picture class="h-100 w-100"> <source media="(min-width: 1400px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02x2_RE4slnY?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 1084px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02x2_RE4slnY?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02x2_RE4slnY?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=3840&amp;qlt=85&amp;fit=constrain 2x"/> <source media="(min-width: 860px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02x2_RE4slnY?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 540px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02375x275_RE4siVs?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02375x275_RE4siVs?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x"/> <img class=" lazyload blur-up lazypreload card-img w-100 " alt="A person looking at a calendar on a tablet while making tea." data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02375x275_RE4siVs?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02375x275_RE4siVs?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image02375x275_RE4siVs?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> </picture> </div> <div class="card-foreground justify-content-center align-self-start "> <div class="container "> <div class="d-flex mt-md-n5 my-lg-5 justify-content-center"> <div class="w-100 w-lg-col-7 w-xl-col-5 "> <div class="card py-5 px-md-5 depth-lg-none bg-lg-transparent-text-dark material-md-card "> <div class="card-body text-lg-center" data-highlight-compname="Highlight (OneCloud) , Card vertical alignment of align-self-start, Card horizontal alignment of justify-content-center, Card size w-lg-col-7 w-xl-col-5, Card transparency set to true"> <div class="mb-0 "> </div> <h2 class="h2 "> Keep your busy life organized </h2> <div class="mb-4" data-oc-token-text> <p>Outlook does more so you can get more done.</p> </div> </div> </div> </div> </div> </div> </div> </div> </section></div> <div class="layout-container responsivegrid mb-6 mt-6 aem-GridColumn aem-GridColumn--default--12" data-component-id="51e927945f39700e952adb9bd3dc97e7"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 grid-image-layout-container-uidb267 heading-bg-color-layout-container-uidb267" data-automation-test-id="layout-container-uidb267"> <style data-automation-test-id="headingColor-layout-container-uidb267">
                    .heading-bg-color-layout-container-uidb267{
                         background-color:  !important;
                    }
          </style> <div class="container" id="layout-container-uidb267" data-componentName="layout-container-uidb267"> <div class="sneakpeekcontentcardscarousel carouselbase carousel aem-GridColumn aem-GridColumn--default--12" data-component-id="1c708ee799a2a136ecdd178482f3d74e"> <section data-oc="oc775a" id="sneakpeekcontentcardscarousel-oc775a"> <div class="row"> <div class="col-12"> <div class="area-heading text-md-center mb-5"> <div class="row"> <div class="col-12 col-md-8 col-xl-6 mx-auto"> <p></p> </div> </div> </div> </div> <div class="col-12 px-0 px-md-g"> <section role="region" aria-label="carousel1" aria-roledescription="slideshow"> <div id="status-container-3957699c-d994-45bb-aeab-2c31ae70c98b"> <span id="status-msg-3957699c-d994-45bb-aeab-2c31ae70c98b" class="sr-only" aria-live="polite">Slide %{start} of %{total}. %{slideTitle}</span> </div> <div class="carousel slide carousel-sneak-peek carousel-content-cards" data-mount="carousel" data-status="status-container-3957699c-d994-45bb-aeab-2c31ae70c98b"> <a href="#3957699c-d994-45bb-aeab-2c31ae70c98b" class="btn btn-link sr-only-focusable w-100 position-absolute">Skip carousel1 </a> <div> <div class="carousel-controls"> <button data-bi-cN="Carousel Back" data-bi-ecN="Carousel Back" data-bi-cT="Button" data-bi-pA="Body" data-bi-compNm="Sneak Peek Content Cards Carousel" data-bi-bhvr="1" type="button" class="carousel-control-prev" data-slide="prev" title="Previous slide"> <span class="sr-only">"Previous slide"</span> </button> <ol class="carousel-indicators" aria-hidden="true"> <li class="active"></li> <li></li> <li></li> <li></li> </ol> <button data-bi-cN="Carousel Forward" data-bi-ecN="Carousel Forward" data-bi-cT="Button" data-bi-pA="Body" data-bi-compNm="Sneak Peek Content Cards Carousel" data-bi-bhvr="3" type="button" class="carousel-control-next" data-slide="next" title="Next slide"> <span class="sr-only">"Next slide"</span> </button> </div> <div class="carousel-inner"> <section class="carousel-item active" tabindex="0" aria-label="1 of 4" role="region" aria-roledescription="slide"> <section data-oc="ocd5b9" id="sneakpeekcontentcards-ocd5b9"> <div class="card h-100 material-card" data-mount="click-group"> <img class="card-img lazyload blur-up lazypreload " alt="A phone screen showing intelligent search including contacts, upcoming calendar events, and files." width="922" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless-Carousel02x2_RE4slnR?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=922&amp;qlt=100&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless-Carousel02x2_RE4slnR?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1844&amp;qlt=100&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless-Carousel02x2_RE4slnR?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=922&amp;qlt=100&amp;fit=constrain"/> <div class="card-body px-4 px-lg-5 pt-4"> <h3 class="h3 pt-4 "> Intelligence that works for you </h3> <p class="mb-3">Locate messages, people, and documents with Outlook search.</p> </div> </div> </section> </section> <section class="carousel-item" tabindex="1" aria-label="2 of 4" role="region" aria-roledescription="slide"> <section data-oc="oc9bd8" id="sneakpeekcontentcards-oc9bd8"> <div class="card h-100 material-card" data-mount="click-group"> <img class="card-img lazyload blur-up lazypreload " alt="A phone screen showing the sender’s availability in an email being composed in Outlook." width="922" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless_Carousel03x2_RE4s3cB?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=922&amp;qlt=100&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless_Carousel03x2_RE4s3cB?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1844&amp;qlt=100&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless_Carousel03x2_RE4s3cB?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=922&amp;qlt=100&amp;fit=constrain"/> <div class="card-body px-4 px-lg-5 pt-4"> <h3 class="h3 pt-4 "> Stay organized and connected </h3> <p class="mb-3"><p>Simplify scheduling by sharing your availability.</p> <p> </p> </p> </div> </div> </section> </section> <section class="carousel-item" tabindex="2" aria-label="3 of 4" role="region" aria-roledescription="slide"> <section data-oc="oc41d7" id="sneakpeekcontentcards-oc41d7"> <div class="card h-100 material-card" data-mount="click-group"> <img class="card-img lazyload blur-up lazypreload " alt="A tablet showing Outlook inbox, with the Task panel open on the right side of the screen" width="922" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless-Carousel01x2_RE4s8qt?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=922&amp;qlt=100&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless-Carousel01x2_RE4s8qt?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1844&amp;qlt=100&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Endless-Carousel01x2_RE4s8qt?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=922&amp;qlt=100&amp;fit=constrain"/> <div class="card-body px-4 px-lg-5 pt-4"> <h3 class="h3 pt-4 "> Stay on top of your day </h3> <p class="mb-3">Prioritize your tasks with Microsoft To Do.</p> </div> </div> </section> </section> <section class="carousel-item" tabindex="3" aria-label="4 of 4" role="region" aria-roledescription="slide"> <section data-oc="oce1b6" id="sneakpeekcontentcards-oce1b6"> <div class="card h-100 material-card" data-mount="click-group"> <img class="card-img lazyload blur-up lazypreload " alt="A mobile phone displaying an Inbox in Outlook." width="922" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/outlook_mobile_app_RE5369E?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=922&amp;qlt=100&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/outlook_mobile_app_RE5369E?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1844&amp;qlt=100&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/outlook_mobile_app_RE5369E?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=922&amp;qlt=100&amp;fit=constrain"/> <div class="card-body px-4 px-lg-5 pt-4"> <h3 class="h3 "> A Lite option for low-resource phones or networks </h3> <p class="mb-3">Get the essentials of Outlook in a fast app with a small download size.</p> </div> <div class="card-footer pt-3 px-4 pb-4 px-lg-5"> <div class=" link-group "> <a data-bi-cn="Try Outlook Lite (Android only)" data-bi-ecn="Try Outlook Lite (Android only)" data-bi-ct="cta" data-bi-pa="body" data-bi-bhvr="81" data-bi-tags="{&#34;BiLinkName&#34;:&#34;TryOutlookLite(AndroidOnly)&#34;}" class="cta cta font-weight-semibold " data-target="https://go.microsoft.com/fwlink/p/?linkid=2202426&amp;culture=en-us&amp;country=ww" aria-label="Try Outlook Lite for Android" target="_blank" data-regenerate-fwlink="true" href="https://go.microsoft.com/fwlink/p/?linkid=2202426&culture=en-us&country=ww"> <span>Try Outlook Lite (Android only)</span> </a> </div> </div> </div> </section> </section> </div> </div> </div> </section> <a id="3957699c-d994-45bb-aeab-2c31ae70c98b" class="sr-only" tabindex="-1">End of carousel1 section</a> </div> </div> </section> <script src="/etc.clientlibs/microsoft/components/content/sneakpeekcontentcardscarousel/v1/sneakpeekcontentcardscarousel/clientlibs/site.min.ACSHASH010b4cd635325aa54c5b0b99c2ba5144.js"></script> <script src="/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-base.min.ACSHASH9664e3d4eae25f97830251e3e5b20248.js"></script> </div> </div> </div></div> <div class="highlight aem-GridColumn aem-GridColumn--default--12" data-component-id="5e1ee03032262058e61848c44cc34b77"> <section data-oc="oc23c8" id="highlight-oc23c8"> <div class="card-img-overlay "> <div class="card-background my-0"> <picture class="h-100 w-100"> <source media="(min-width: 1400px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps_1902x700@2x_RE4slnO?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 1084px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps_1902x700@2x_RE4slnO?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps_1902x700@2x_RE4slnO?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=3840&amp;qlt=85&amp;fit=constrain 2x"/> <source media="(min-width: 860px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps_1902x700@2x_RE4slnO?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 540px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps375x275_RE4slod?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps375x275_RE4slod?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x"/> <img class=" lazyload blur-up lazypreload card-img w-100 " alt="3D logos of various Office apps including OneDrive, Excel, Outlook, Word, PowerPoint, and OneNote" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps375x275_RE4slod?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps375x275_RE4slod?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Story-blade-apps375x275_RE4slod?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> </picture> </div> <div class="card-foreground "> <div class="container "> <div class="d-flex mt-md-n5 my-lg-5 "> <div class="w-100 w-lg-col-4 "> <div class="card py-5 px-md-5 depth-lg-none bg-lg-transparent-text-dark material-md-card "> <div class="card-body " data-highlight-compname="Highlight (OneCloud) , Card size w-lg-col-4, Card transparency set to true"> <div class="mb-0 "> </div> <h2 class="h2 "> Free access to Office apps </h2> <div class="mb-4" data-oc-token-text> <p>Collaborating is easy with Word, PowerPoint, and Excel. You can chat in real time with Skype—right from your Outlook account.</p> </div> </div> </div> </div> </div> </div> </div> </div> </section></div> <div class="highlight aem-GridColumn aem-GridColumn--default--12" data-component-id="5e1ee03032262058e61848c44cc34b77"> <section data-oc="oc23c8" id="highlight-oc23c8"> <div class="card-img-overlay "> <div class="card-background my-0"> <picture class="h-100 w-100"> <source media="(min-width: 1400px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03x2_RE4slnK?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 1084px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03x2_RE4slnK?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03x2_RE4slnK?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=3840&amp;qlt=85&amp;fit=constrain 2x"/> <source media="(min-width: 860px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03x2_RE4slnK?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 540px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03375x275_RE4sdyI?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03375x275_RE4sdyI?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x"/> <img class=" lazyload blur-up lazypreload card-img w-100 " alt="A person with visual impairment using a laptop." data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03375x275_RE4sdyI?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03375x275_RE4sdyI?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image03375x275_RE4sdyI?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> </picture> </div> <div class="card-foreground justify-content-end "> <div class="container "> <div class="d-flex mt-md-n5 my-lg-5 justify-content-end"> <div class="w-100 w-lg-col-4 "> <div class="card py-5 px-md-5 depth-lg-none bg-lg-transparent-text-dark material-md-card "> <div class="card-body " data-highlight-compname="Highlight (OneCloud) , Card horizontal alignment of justify-content-end, Card size w-lg-col-4, Card transparency set to true"> <div class="mb-0 "> </div> <h2 class="h2 "> More accessible than ever </h2> <div class="mb-4" data-oc-token-text> <p>We’ve designed Outlook to be everyone’s most accessible inbox, with intuitive, voice-controlled navigation, support for multiple assistive devices, and more.</p> </div> </div> </div> </div> </div> </div> </div> </div> </section></div> <div class="highlight aem-GridColumn aem-GridColumn--default--12" data-component-id="5e1ee03032262058e61848c44cc34b77"> <section data-oc="oc23c8" id="highlight-oc23c8"> <div class="card-img-overlay "> <div class="card-background my-0"> <picture class="h-100 w-100"> <source media="(min-width: 1400px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image04--x2_RE4slnH?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image04--x2_RE4slnH?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=3840&amp;qlt=85&amp;fit=constrain 2x"/> <source media="(min-width: 1084px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image04--x2_RE4slnH?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image04--x2_RE4slnH?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=3840&amp;qlt=85&amp;fit=constrain 2x"/> <source media="(min-width: 860px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image04--x2_RE4slnH?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=1920&amp;qlt=85&amp;fit=constrain"/> <source media="(min-width: 540px)" data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image_04375x275_RE4s3cM?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image_04375x275_RE4s3cM?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x"/> <img class=" lazyload blur-up lazypreload card-img w-100 " alt="A tablet screen showing PowerPoint and OneDrive open side by side and a phone screen showing an Outlook calendar." data-srcset="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image_04375x275_RE4s3cM?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain, https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image_04375x275_RE4s3cM?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=750&amp;hei=550&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain 2x" data-src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Immersive-Module-image_04375x275_RE4s3cM?resMode=sharp2&amp;op_usm=1.5,0.65,15,0&amp;wid=375&amp;hei=275&amp;qlt=85&amp;fmt=png-alpha&amp;fit=constrain"/> </picture> </div> <div class="card-foreground justify-content-end "> <div class="container "> <div class="d-flex mt-md-n5 my-lg-5 justify-content-end"> <div class="w-100 w-lg-col-4 "> <div class="card py-5 px-md-5 depth-lg-none bg-lg-transparent material-md-card "> <div class="card-body " data-highlight-compname="Highlight (OneCloud) , Card horizontal alignment of justify-content-end, Card size w-lg-col-4, Card transparency set to true"> <div class="mb-0 "> </div> <h2 class="h2 "> Expand your Outlook </h2> <div class="mb-4" data-oc-token-text> <p>A Microsoft 365 subscription includes premium Outlook features like an ad-free interface, enhanced security, the full desktop version of Office apps, and 1 TB of cloud storage.</p> </div> <div class=" link-group "> <a data-bi-cn="Learn about premium" data-bi-ecn="Learn about premium" data-bi-ct="cta" data-bi-pa="body" data-bi-bhvr="230" data-bi-tags="{&#34;BiLinkName&#34;:&#34;LearnAboutPremium&#34;}" class="cta cta font-weight-semibold " data-target="https://www.microsoft.com/en/microsoft-365/outlook/outlook-personal-email-plans" aria-label="Learn about premium Outlook personal email plans" target="_self" href="https://www.microsoft.com/en/microsoft-365/outlook/outlook-personal-email-plans"> <span>Learn about premium</span> </a> </div> </div> </div> </div> </div> </div> </div> </div> </section></div> <div class="targeting-container aem-GridColumn aem-GridColumn--default--12" data-component-id="3a796505b6c04fa385e30bdb1b3679f7">  </div> <div class="layout-container responsivegrid pb-6 pt-6 material-color-primary aem-GridColumn aem-GridColumn--default--12" data-component-id="51e927945f39700e952adb9bd3dc97e7"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 grid-image-layout-container-uidd9b6 material-color-primary heading-bg-color-layout-container-uidd9b6" data-automation-test-id="layout-container-uidd9b6"> <style data-automation-test-id="headingColor-layout-container-uidd9b6">
                    .heading-bg-color-layout-container-uidd9b6{
                         background-color:  !important;
                    }
          </style> <div class="container" id="layout-container-uidd9b6" data-componentName="layout-container-uidd9b6"> <div class="heading aem-GridColumn aem-GridColumn--default--12" data-component-id="9b992e252846bf14b532f40bd58c2fbf"> <section data-oc="oc98e0" id="heading-oc98e0"> <h2 class="mb-n4 text-center "> Looking for Hotmail? </h2> </section> </div> <div class="areaheading aem-GridColumn aem-GridColumn--default--12" data-component-id="54a8759731545a237e6d9c861d7dd0a3"> <section data-oc="occ0ea" id="areaheading-occ0ea"> <div class=" text-md-center depth-none area-heading rounded"> <div class="row py-4 justify-content-center "> <div class="col-12 col-md-8 mx-auto"> </div> <div class="col-12 col-md-8 col-xl-6 mx-auto"> <div data-oc-token-text> <div style="text-align: center;">You've found it. We've redesigned and relaunched Hotmail as Outlook. We're still committed to building the best free email and calendar.</div> </div> </div> </div> </div> </section> <script src="/etc.clientlibs/onecloud/components/content/areaheading/v1/areaheading/clientlibs/site.min.ACSHASHf3ce0716faf38b81e39f92e91d6f05dc.js"></script> </div> </div> </div></div> <div class="divider-component aem-GridColumn aem-GridColumn--default--12" data-component-id="596e5fa739d15607c6adc6715f1e064e"> <div class="divider border-neutral-200"></div> </div> <div class="layout-container responsivegrid mt-5 aem-GridColumn aem-GridColumn--default--12" data-component-id="51e927945f39700e952adb9bd3dc97e7"> <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 grid-image-layout-container-uidfa83 heading-bg-color-layout-container-uidfa83" data-automation-test-id="layout-container-uidfa83"> <style data-automation-test-id="headingColor-layout-container-uidfa83">
                    .heading-bg-color-layout-container-uidfa83{
                         background-color:  !important;
                    }
          </style> <div class="container" id="layout-container-uidfa83" data-componentName="layout-container-uidfa83"> <div class="socialfollow aem-GridColumn aem-GridColumn--default--12" data-component-id="f881184c0350e55b789024b15f22837e"> <link rel="canonical" href="https://www.microsoft.com/en/microsoft-365/outlook/email-and-calendar-software-microsoft-outlook"/> <section class="col-12" id="socialfollow-uidbd4" data-componentName="socialfollow-uidbd4"> <h2 class="base font-weight-normal d-inline align-middle mr-g"> Follow Microsoft 365 </h2> <ul class="list-inline d-inline-block align-middle mb-0"> <li class="list-inline-item mr-g"> <a class="d-inline-block" href="https://go.microsoft.com/fwlink/p/?linkid=2144764" target="_blank" aria-label="Follow Microsoft 365 on Linkedin" data-bi-ecn="LinkedIn" data-bi-bhvr="126" data-bi-cn="LinkedIn" data-bi-socchn="LinkedIn" data-bi-ct="Social Button" data-bi-pa="body" data-bi-compnm="Social Follow - horizontal"> <img src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/LinkedIn-29?scl=1" alt="linkedin logo" title="LinkedIn" width="32" height="32"/> </a> </li> <li class="list-inline-item mr-g"> <a class="d-inline-block" href="https://go.microsoft.com/fwlink/p/?LinkId=2000804" target="_blank" aria-label="Follow Microsoft 365 on Twitter" data-bi-ecn="Twitter" data-bi-bhvr="126" data-bi-cn="Twitter" data-bi-socchn="Twitter" data-bi-ct="Social Button" data-bi-pa="body" data-bi-compnm="Social Follow - horizontal"> <img src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Twitter-34?scl=1" alt="Twitter logo" title="Twitter" width="32" height="32"/> </a> </li> <li class="list-inline-item mr-g"> <a class="d-inline-block" href="https://go.microsoft.com/fwlink/p/?LinkID=2000803" target="_blank" aria-label="Follow Microsoft 365 on Microsoft 365 Blog" data-bi-ecn="Blog" data-bi-bhvr="126" data-bi-cn="Blog" data-bi-socchn="Blog" data-bi-ct="Social Button" data-bi-pa="body" data-bi-compnm="Social Follow - horizontal"> <img src="https://cdn-dynmedia-1.microsoft.com/is/image/microsoftcorp/Blog?scl=1" alt="Blog logo" title="Blog" width="32" height="32"/> </a> </li> </ul> <script type="application/ld+json">
            {
                "@context": "https://schema.org",
                "@type": "Organization",
                "name": "Microsoft",
                "url": "https://www.microsoft.com/",
                "sameAs":["https://go.microsoft.com/fwlink/p/?linkid\u003d2144764","https://go.microsoft.com/fwlink/p/?LinkId\u003d2000804","https://go.microsoft.com/fwlink/p/?LinkID\u003d2000803"]
            };
        </script> </section> </div> </div> </div></div> </div> </div> </div> </main></div> <div class="universalfooter aem-GridColumn aem-GridColumn--default--12" data-component-id="873fa1f863becf63b38092282d4ea0b1">             <div id="footerArea" class="uhf"  data-m='{"cN":"footerArea","cT":"Area_coreuiArea","id":"a2Body","sN":2,"aN":"Body"}'>
                <div id="footerRegion"      data-region-key="footerregion" data-m='{"cN":"footerRegion","cT":"Region_coreui-region","id":"r1a2","sN":1,"aN":"a2"}' >

    <div  id="footerUniversalFooter" data-m='{"cN":"footerUniversalFooter","cT":"Module_coreui-universalfooter","id":"m1r1a2","sN":1,"aN":"r1a2"}'  data-module-id="Category|footerRegion|coreui-region|footerUniversalFooter|coreui-universalfooter">
        



<footer id="uhf-footer" class="c-uhff context-uhf"  data-uhf-mscc-rq="false" data-footer-footprint="/OfficeProducts/SPEFooter, fromService: True" data-m='{"cN":"Uhf footer_cont","cT":"Container","id":"c1m1r1a2","sN":1,"aN":"m1r1a2"}'>
        <nav class="c-uhff-nav" aria-label="Footer Resource links" data-m='{"cN":"Footer nav_cont","cT":"Container","id":"c1c1m1r1a2","sN":1,"aN":"c1m1r1a2"}'>
            
                <div class="c-uhff-nav-row">
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn1_cont","cT":"Container","id":"c1c1c1m1r1a2","sN":1,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">What&#39;s new</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Surface Book 3 What&#39;s new" class="c-uhff-link" href="https://www.microsoft.com/es-us/p/surface-book-3/8XBW9G3Z71F1" data-m='{"cN":"Footer_WhatsNew_SurfaceBook3_nav","id":"n1c1c1c1m1r1a2","sN":1,"aN":"c1c1c1m1r1a2"}'>Surface Book 3</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft 365 What&#39;s new" class="c-uhff-link" href="https://www.microsoft.com/microsoft-365" data-m='{"cN":"Footer_WhatsNew_Microsoft365_nav","id":"n2c1c1c1m1r1a2","sN":2,"aN":"c1c1c1m1r1a2"}'>Microsoft 365</a>
                            </li>
                            <li>
                                <a aria-label="Surface Pro What&#39;s new" class="c-uhff-link" href="https://www.microsoft.com/en-us/surface/devices/surface-pro/overview" data-m='{"cN":"Footer_WhatsNew_NewSurfacePro_nav","id":"n3c1c1c1m1r1a2","sN":3,"aN":"c1c1c1m1r1a2"}'>Surface Pro</a>
                            </li>
                            <li>
                                <a aria-label="Windows 11 apps What&#39;s new" class="c-uhff-link" href="https://www.microsoft.com/windows/windows-11-apps" data-m='{"cN":"Footer_WhatsNew_Windows_11_apps_nav","id":"n4c1c1c1m1r1a2","sN":4,"aN":"c1c1c1m1r1a2"}'>Windows 11 apps</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn2_cont","cT":"Container","id":"c2c1c1m1r1a2","sN":2,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">Microsoft Store</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Account profile Microsoft Store" class="c-uhff-link" href="https://account.microsoft.com/" data-m='{"cN":"Footer_StoreandSupport_AccountProfile_nav","id":"n1c2c1c1m1r1a2","sN":1,"aN":"c2c1c1m1r1a2"}'>Account profile</a>
                            </li>
                            <li>
                                <a aria-label="Download Center Microsoft Store" class="c-uhff-link" href="https://www.microsoft.com/en-us/download" data-m='{"cN":"Footer_StoreandSupport_DownloadCenter_nav","id":"n2c2c1c1m1r1a2","sN":2,"aN":"c2c1c1m1r1a2"}'>Download Center</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Store Support Microsoft Store" class="c-uhff-link" href="https://go.microsoft.com/fwlink/?linkid=2139749" data-m='{"cN":"Footer_StoreandSupport_SalesAndSupport_nav","id":"n3c2c1c1m1r1a2","sN":3,"aN":"c2c1c1m1r1a2"}'>Microsoft Store Support</a>
                            </li>
                            <li>
                                <a aria-label="Extended holiday returns Microsoft Store" class="c-uhff-link" href="https://www.microsoft.com/en-us/store/b/extended-holiday-returns?icid=gm_fy18_hol_uhf_footer_whatsnew_extendedreturns" data-m='{"cN":"Footer_StoreandSupport_Returns_nav","id":"n4c2c1c1m1r1a2","sN":4,"aN":"c2c1c1m1r1a2"}'>Extended holiday returns</a>
                            </li>
                            <li>
                                <a aria-label="Order tracking Microsoft Store" class="c-uhff-link" href="https://account.microsoft.com/orders" data-m='{"cN":"Footer_StoreandSupport_OrderTracking_nav","id":"n5c2c1c1m1r1a2","sN":5,"aN":"c2c1c1m1r1a2"}'>Order tracking</a>
                            </li>
                            <li>
                                <a aria-label="Support Microsoft Store" class="c-uhff-link" href="https://support.microsoft.com/en-us" data-m='{"cN":"Footer_StoreandSupport_Support_nav","id":"n6c2c1c1m1r1a2","sN":6,"aN":"c2c1c1m1r1a2"}'>Support</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn3_cont","cT":"Container","id":"c3c1c1m1r1a2","sN":3,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">Education</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Microsoft in education Education" class="c-uhff-link" href="https://www.microsoft.com/education" data-m='{"cN":"Footer_Education_MicrosoftInEducation_nav","id":"n1c3c1c1m1r1a2","sN":1,"aN":"c3c1c1m1r1a2"}'>Microsoft in education</a>
                            </li>
                            <li>
                                <a aria-label="Devices for education Education" class="c-uhff-link" href="https://www.microsoft.com/education/devices/overview" data-m='{"cN":"Footer_Education_DevicesforEducation_nav","id":"n2c3c1c1m1r1a2","sN":2,"aN":"c3c1c1m1r1a2"}'>Devices for education</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Teams for Education Education" class="c-uhff-link" href="https://www.microsoft.com/education/products/teams" data-m='{"cN":"Footer_Education_MicrosoftTeamsforEducation_nav","id":"n3c3c1c1m1r1a2","sN":3,"aN":"c3c1c1m1r1a2"}'>Microsoft Teams for Education</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft 365 Education Education" class="c-uhff-link" href="https://www.microsoft.com/education/buy-license/microsoft365" data-m='{"cN":"Footer_Education_Microsoft365Education_nav","id":"n4c3c1c1m1r1a2","sN":4,"aN":"c3c1c1m1r1a2"}'>Microsoft 365 Education</a>
                            </li>
                            <li>
                                <a aria-label="Office Education Education" class="c-uhff-link" href="https://www.microsoft.com/education/products/office" data-m='{"cN":"Footer_Education_Office Education_nav","id":"n5c3c1c1m1r1a2","sN":5,"aN":"c3c1c1m1r1a2"}'>Office Education</a>
                            </li>
                            <li>
                                <a aria-label="Educator training and development Education" class="c-uhff-link" href="https://education.microsoft.com/" data-m='{"cN":"Footer_Education_EducatorTrainingDevelopment_nav","id":"n6c3c1c1m1r1a2","sN":6,"aN":"c3c1c1m1r1a2"}'>Educator training and development</a>
                            </li>
                            <li>
                                <a aria-label="Deals for students and parents Education" class="c-uhff-link" href="https://www.microsoft.com/en-us/store/b/education" data-m='{"cN":"Footer_Education_DealsForStudentsandParents_nav","id":"n7c3c1c1m1r1a2","sN":7,"aN":"c3c1c1m1r1a2"}'>Deals for students and parents</a>
                            </li>
                            <li>
                                <a aria-label="Azure for students Education" class="c-uhff-link" href="https://azure.microsoft.com/free/students/" data-m='{"cN":"Footer_Education_Azureforstudents_nav","id":"n8c3c1c1m1r1a2","sN":8,"aN":"c3c1c1m1r1a2"}'>Azure for students</a>
                            </li>

                        </ul>
                        
                    </div>
                </div>
                <div class="c-uhff-nav-row">
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn4_cont","cT":"Container","id":"c4c1c1m1r1a2","sN":4,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">Business</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Microsoft Cloud Business" class="c-uhff-link" href="https://www.microsoft.com/microsoft-cloud" data-m='{"cN":"Footer_Business_Microsoft_Cloud_nav","id":"n1c4c1c1m1r1a2","sN":1,"aN":"c4c1c1m1r1a2"}'>Microsoft Cloud</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Security Business" class="c-uhff-link" href="https://www.microsoft.com/security" data-m='{"cN":"Footer_Business_Microsoft Security_nav","id":"n2c4c1c1m1r1a2","sN":2,"aN":"c4c1c1m1r1a2"}'>Microsoft Security</a>
                            </li>
                            <li>
                                <a aria-label="Azure Business" class="c-uhff-link" href="https://azure.microsoft.com/" data-m='{"cN":"Footer_DeveloperAndIT_MicrosoftAzure_nav","id":"n3c4c1c1m1r1a2","sN":3,"aN":"c4c1c1m1r1a2"}'>Azure</a>
                            </li>
                            <li>
                                <a aria-label="Dynamics 365 Business" class="c-uhff-link" href="https://dynamics.microsoft.com/" data-m='{"cN":"Footer_Business_MicrosoftDynamics365_nav","id":"n4c4c1c1m1r1a2","sN":4,"aN":"c4c1c1m1r1a2"}'>Dynamics 365</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft 365 Business" class="c-uhff-link" href="https://www.microsoft.com/microsoft-365/business/" data-m='{"cN":"Footer_Business_M365_nav","id":"n5c4c1c1m1r1a2","sN":5,"aN":"c4c1c1m1r1a2"}'>Microsoft 365</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Advertising Business" class="c-uhff-link" href="https://about.ads.microsoft.com" data-m='{"cN":"Footer_MicrosoftAdvertising_nav","id":"n6c4c1c1m1r1a2","sN":6,"aN":"c4c1c1m1r1a2"}'>Microsoft Advertising</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Industry Business" class="c-uhff-link" href="https://www.microsoft.com/industry" data-m='{"cN":"Footer_Business_MicrosoftIndustry_nav","id":"n7c4c1c1m1r1a2","sN":7,"aN":"c4c1c1m1r1a2"}'>Microsoft Industry</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Teams Business" class="c-uhff-link" href="https://www.microsoft.com/microsoft-teams/group-chat-software" data-m='{"cN":"Footer_Business_Microsoft365_nav","id":"n8c4c1c1m1r1a2","sN":8,"aN":"c4c1c1m1r1a2"}'>Microsoft Teams</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn5_cont","cT":"Container","id":"c5c1c1m1r1a2","sN":5,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">Developer &amp; IT</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Developer Center Developer &amp; IT" class="c-uhff-link" href="https://developer.microsoft.com/" data-m='{"cN":"Footer_DeveloperAndIT_DeveloperCenter_nav","id":"n1c5c1c1m1r1a2","sN":1,"aN":"c5c1c1m1r1a2"}'>Developer Center</a>
                            </li>
                            <li>
                                <a aria-label="Documentation Developer &amp; IT" class="c-uhff-link" href="https://learn.microsoft.com/docs/" data-m='{"cN":"Footer_DeveloperAndIT_Documentation_nav","id":"n2c5c1c1m1r1a2","sN":2,"aN":"c5c1c1m1r1a2"}'>Documentation</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Learn Developer &amp; IT" class="c-uhff-link" href="https://learn.microsoft.com/" data-m='{"cN":"Footer_DeveloperAndIT_MicrosoftLearn_nav","id":"n3c5c1c1m1r1a2","sN":3,"aN":"c5c1c1m1r1a2"}'>Microsoft Learn</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Tech Community Developer &amp; IT" class="c-uhff-link" href="https://techcommunity.microsoft.com/" data-m='{"cN":"Footer_DeveloperAndIT_MicrosoftTechCommunity_nav","id":"n4c5c1c1m1r1a2","sN":4,"aN":"c5c1c1m1r1a2"}'>Microsoft Tech Community</a>
                            </li>
                            <li>
                                <a aria-label="Azure Marketplace Developer &amp; IT" class="c-uhff-link" href="https://azuremarketplace.microsoft.com/" data-m='{"cN":"Footer_DeveloperAndIT_AzureMarketplace_nav","id":"n5c5c1c1m1r1a2","sN":5,"aN":"c5c1c1m1r1a2"}'>Azure Marketplace</a>
                            </li>
                            <li>
                                <a aria-label="AppSource Developer &amp; IT" class="c-uhff-link" href="https://appsource.microsoft.com/" data-m='{"cN":"Footer_DeveloperAndIT_AppSource_nav","id":"n6c5c1c1m1r1a2","sN":6,"aN":"c5c1c1m1r1a2"}'>AppSource</a>
                            </li>
                            <li>
                                <a aria-label="Microsoft Power Platform Developer &amp; IT" class="c-uhff-link" href="https://powerplatform.microsoft.com/" data-m='{"cN":"Footer_DeveloperAndIT_Power Platform_nav","id":"n7c5c1c1m1r1a2","sN":7,"aN":"c5c1c1m1r1a2"}'>Microsoft Power Platform</a>
                            </li>
                            <li>
                                <a aria-label="Visual Studio Developer &amp; IT" class="c-uhff-link" href="https://visualstudio.microsoft.com/" data-m='{"cN":"Footer_DeveloperAndIT_MicrosoftVisualStudio_nav","id":"n8c5c1c1m1r1a2","sN":8,"aN":"c5c1c1m1r1a2"}'>Visual Studio</a>
                            </li>

                        </ul>
                        
                    </div>
                    <div class="c-uhff-nav-group" data-m='{"cN":"footerNavColumn6_cont","cT":"Container","id":"c6c1c1m1r1a2","sN":6,"aN":"c1c1m1r1a2"}'>
                        <div class="c-heading-4" role="heading" aria-level="2">Company</div>
                        <ul class="c-list f-bare">
                            <li>
                                <a aria-label="Careers Company" class="c-uhff-link" href="https://careers.microsoft.com/" data-m='{"cN":"Footer_Company_Careers_nav","id":"n1c6c1c1m1r1a2","sN":1,"aN":"c6c1c1m1r1a2"}'>Careers</a>
                            </li>
                            <li>
                                <a aria-label="About Microsoft Company" class="c-uhff-link" href="https://www.microsoft.com/en-us/about" data-m='{"cN":"Footer_Company_AboutMicrosoft_nav","id":"n2c6c1c1m1r1a2","sN":2,"aN":"c6c1c1m1r1a2"}'>About Microsoft</a>
                            </li>
                            <li>
                                <a aria-label="Company news Company" class="c-uhff-link" href="https://news.microsoft.com/" data-m='{"cN":"Footer_Company_CompanyNews_nav","id":"n3c6c1c1m1r1a2","sN":3,"aN":"c6c1c1m1r1a2"}'>Company news</a>
                            </li>
                            <li>
                                <a aria-label="Privacy at Microsoft Company" class="c-uhff-link" href="https://privacy.microsoft.com" data-m='{"cN":"Footer_Company_PrivacyAtMicrosoft_nav","id":"n4c6c1c1m1r1a2","sN":4,"aN":"c6c1c1m1r1a2"}'>Privacy at Microsoft</a>
                            </li>
                            <li>
                                <a aria-label="Investors Company" class="c-uhff-link" href="https://www.microsoft.com/investor/default.aspx" data-m='{"cN":"Footer_Company_Investors_nav","id":"n5c6c1c1m1r1a2","sN":5,"aN":"c6c1c1m1r1a2"}'>Investors</a>
                            </li>
                            <li>
                                <a aria-label="Diversity and inclusion Company" class="c-uhff-link" href="https://www.microsoft.com/en-us/diversity/" data-m='{"cN":"Footer_Company_DiversityAndInclusion_nav","id":"n6c6c1c1m1r1a2","sN":6,"aN":"c6c1c1m1r1a2"}'>Diversity and inclusion</a>
                            </li>
                            <li>
                                <a aria-label="Accessibility Company" class="c-uhff-link" href="https://www.microsoft.com/en-us/accessibility" data-m='{"cN":"Footer_Company_Accessibility_nav","id":"n7c6c1c1m1r1a2","sN":7,"aN":"c6c1c1m1r1a2"}'>Accessibility</a>
                            </li>
                            <li>
                                <a aria-label="Sustainability Company" class="c-uhff-link" href="https://www.microsoft.com/sustainability/" data-m='{"cN":"Footer_Company_Sustainability_nav","id":"n8c6c1c1m1r1a2","sN":8,"aN":"c6c1c1m1r1a2"}'>Sustainability</a>
                            </li>

                        </ul>
                        
                    </div>
                </div>
        </nav>
    <div class="c-uhff-base">
                <a id="locale-picker-link" aria-label="Content Language Selector. Currently set to English (Other)" class="c-uhff-link c-uhff-lang-selector c-glyph glyph-world" href="https://www.microsoft.com/en/microsoft-365/locale" data-m='{"cN":"locale_picker(WW)_nav","id":"n7c1c1m1r1a2","sN":7,"aN":"c1c1m1r1a2"}'>English (Other)</a>

            <a data-m='{"id":"n8c1c1m1r1a2","sN":8,"aN":"c1c1m1r1a2"}' href="https://aka.ms/yourcaliforniaprivacychoices" class='c-uhff-link c-uhff-ccpa'>
        <svg role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 14" xml:space="preserve" height="16" width="43">
            <title>California Consumer Privacy Act (CCPA) Opt-Out Icon</title>
            <path d="M7.4 12.8h6.8l3.1-11.6H7.4C4.2 1.2 1.6 3.8 1.6 7s2.6 5.8 5.8 5.8z" style="fill-rule:evenodd;clip-rule:evenodd;fill:#fff"/>
            <path d="M22.6 0H7.4c-3.9 0-7 3.1-7 7s3.1 7 7 7h15.2c3.9 0 7-3.1 7-7s-3.2-7-7-7zm-21 7c0-3.2 2.6-5.8 5.8-5.8h9.9l-3.1 11.6H7.4c-3.2 0-5.8-2.6-5.8-5.8z" style="fill-rule:evenodd;clip-rule:evenodd;fill:#06f"/>
            <path d="M24.6 4c.2.2.2.6 0 .8L22.5 7l2.2 2.2c.2.2.2.6 0 .8-.2.2-.6.2-.8 0l-2.2-2.2-2.2 2.2c-.2.2-.6.2-.8 0-.2-.2-.2-.6 0-.8L20.8 7l-2.2-2.2c-.2-.2-.2-.6 0-.8.2-.2.6-.2.8 0l2.2 2.2L23.8 4c.2-.2.6-.2.8 0z" style="fill:#fff"/>
            <path d="M12.7 4.1c.2.2.3.6.1.8L8.6 9.8c-.1.1-.2.2-.3.2-.2.1-.5.1-.7-.1L5.4 7.7c-.2-.2-.2-.6 0-.8.2-.2.6-.2.8 0L8 8.6l3.8-4.5c.2-.2.6-.2.9 0z" style="fill:#06f"/>
        </svg>
        <span>Your Privacy Choices</span>
    </a>

        <noscript>
                <a data-m='{"id":"n9c1c1m1r1a2","sN":9,"aN":"c1c1m1r1a2"}' href="https://aka.ms/yourcaliforniaprivacychoices" class='c-uhff-link c-uhff-ccpa'>
        <svg role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 14" xml:space="preserve" height="16" width="43">
            <title>California Consumer Privacy Act (CCPA) Opt-Out Icon</title>
            <path d="M7.4 12.8h6.8l3.1-11.6H7.4C4.2 1.2 1.6 3.8 1.6 7s2.6 5.8 5.8 5.8z" style="fill-rule:evenodd;clip-rule:evenodd;fill:#fff"/>
            <path d="M22.6 0H7.4c-3.9 0-7 3.1-7 7s3.1 7 7 7h15.2c3.9 0 7-3.1 7-7s-3.2-7-7-7zm-21 7c0-3.2 2.6-5.8 5.8-5.8h9.9l-3.1 11.6H7.4c-3.2 0-5.8-2.6-5.8-5.8z" style="fill-rule:evenodd;clip-rule:evenodd;fill:#06f"/>
            <path d="M24.6 4c.2.2.2.6 0 .8L22.5 7l2.2 2.2c.2.2.2.6 0 .8-.2.2-.6.2-.8 0l-2.2-2.2-2.2 2.2c-.2.2-.6.2-.8 0-.2-.2-.2-.6 0-.8L20.8 7l-2.2-2.2c-.2-.2-.2-.6 0-.8.2-.2.6-.2.8 0l2.2 2.2L23.8 4c.2-.2.6-.2.8 0z" style="fill:#fff"/>
            <path d="M12.7 4.1c.2.2.3.6.1.8L8.6 9.8c-.1.1-.2.2-.3.2-.2.1-.5.1-.7-.1L5.4 7.7c-.2-.2-.2-.6 0-.8.2-.2.6-.2.8 0L8 8.6l3.8-4.5c.2-.2.6-.2.9 0z" style="fill:#06f"/>
        </svg>
        <span>Your Privacy Choices</span>
    </a>

        </noscript>
        <nav aria-label="Microsoft corporate links">
            <ul class="c-list f-bare" data-m='{"cN":"Corp links_cont","cT":"Container","id":"c10c1c1m1r1a2","sN":10,"aN":"c1c1m1r1a2"}'>
                                <li  id="c-uhff-footer_contactus">
                    <a class="c-uhff-link" href="https://support.microsoft.com/contactus" data-mscc-ic="false" data-m='{"cN":"Footer_ContactUs_nav","id":"n1c10c1c1m1r1a2","sN":1,"aN":"c10c1c1m1r1a2"}'>Contact Microsoft</a>
                </li>
                <li  id="c-uhff-footer_privacyandcookies">
                    <a class="c-uhff-link" href="https://go.microsoft.com/fwlink/?LinkId=521839" data-mscc-ic="false" data-m='{"cN":"Footer_PrivacyandCookies_nav","id":"n2c10c1c1m1r1a2","sN":2,"aN":"c10c1c1m1r1a2"}'>Privacy </a>
                </li>
                <li class=" x-hidden" id="c-uhff-footer_managecookies">
                    <a class="c-uhff-link" href="#" data-mscc-ic="false" data-m='{"cN":"Footer_ManageCookies_nav","id":"n3c10c1c1m1r1a2","sN":3,"aN":"c10c1c1m1r1a2"}'>Manage cookies</a>
                </li>
                <li  id="c-uhff-footer_termsofuse">
                    <a class="c-uhff-link" href="https://go.microsoft.com/fwlink/?LinkID=206977" data-mscc-ic="false" data-m='{"cN":"Footer_TermsOfUse_nav","id":"n4c10c1c1m1r1a2","sN":4,"aN":"c10c1c1m1r1a2"}'>Terms of use</a>
                </li>
                <li  id="c-uhff-footer_trademarks">
                    <a class="c-uhff-link" href="https://go.microsoft.com/fwlink/?linkid=2196228" data-mscc-ic="false" data-m='{"cN":"Footer_Trademarks_nav","id":"n5c10c1c1m1r1a2","sN":5,"aN":"c10c1c1m1r1a2"}'>Trademarks</a>
                </li>
                <li  id="c-uhff-footer_aboutourads">
                    <a class="c-uhff-link" href="https://choice.microsoft.com" data-mscc-ic="false" data-m='{"cN":"Footer_AboutourAds_nav","id":"n6c10c1c1m1r1a2","sN":6,"aN":"c10c1c1m1r1a2"}'>About our ads</a>
                </li>

                <li>&#169; Microsoft 2023</li>
                
            </ul>
        </nav>
    </div>
    
</footer>

<script id="uhf-footer-ccpa">
    const globalPrivacyControlEnabled = navigator.globalPrivacyControl;

    const GPC_DataSharingOptIn = (globalPrivacyControlEnabled) ? false : checkThirdPartyAdsOptOutCookie();

    function checkThirdPartyAdsOptOutCookie() {
        try {
            const ThirdPartyAdsOptOutCookieName = '3PAdsOptOut';
            var cookieValue = getCookie(ThirdPartyAdsOptOutCookieName);
            return cookieValue != 1;
        } catch {
            return true;
        }
    }

    function getCookie(cookieName) {
        var cookieValue = document.cookie.match('(^|;)\\s*' + cookieName + '\\s*=\\s*([^;]+)');
        return (cookieValue) ? cookieValue[2] : '';
    }
</script>





    </div>
        </div>

    </div>
<script src="https://wcpstatic.microsoft.com/mscc/lib/v2/wcp-consent.js"></script><script src="https://www.microsoft.com/onerfstatics/marketingsites-neu-prod/shell/_scrf/js/themes=default/8e-e88b64/82-2a4f02/49-a00ab0/92-02e55d/7c-dcea75/75-fca72d/ed-e77ee7/d5-bf34c0/a9-078595/7a-7ea8cc/2d-40bdad/23-e8cd2b/96-eb5423/e6-6b0cce/d1-98d78a/c6-082272/a7-f7a340/1e-addbef/2e-ca165a/fc-169dd8/8e-60935c/87-fecbed/96-6ed6eb/c3-eb62e0/ad-ffd6bf/35-621acc/5b-6eff60/b0-07f293/1e-9d9d16/52-f0367f/af-abd754/bf-517249/e1-ed258e/20-0b10e2/6b-0f1117/fb-5e9831/a2-598841?ver=2.0&_cf=20210618&iife=1"></script><script src="https://mem.gfx.ms/meversion?partner=OfficeProducts&market=en-ww&uhf=1" defer></script>  </div> </div> </div> <script src="/etc.clientlibs/onecloud/clientlibs/clientlib-mwf-new/main-outlook.min.ACSHASH1315b52070fe169b25b7b0a6e3667170.js"></script> <script src="/etc.clientlibs/onecloud/clientlibs/clientlib-mwf-ext/main-outlook.min.ACSHASHa760728ce5bdc04f3965db30038cbe0c.js"></script> <script src="/etc.clientlibs/onecloud/clientlibs/clientlib-site.min.ACSHASH4c1f1c6a4ff877c820e56e5ab869262b.js"></script> <script src="/etc.clientlibs/microsoft/clientlibs/clientlib-httpclient.min.ACSHASHdb9337465e1d526f2fff5b4bc44978f0.js"></script> <script src="/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-cookieconsent.min.ACSHASH96f0c5b1219e39b8788028f5c17a5ad9.js"></script> <script src="/etc.clientlibs/onecloud/clientlibs/clientlib-cookievalidator.min.ACSHASH3db5cf9fd3fab92b3889302c8de78d1b.js"></script> <script src="/etc.clientlibs/microsoft/components/structure/page/clientlibs/featurecontrol.min.ACSHASHc22ea5b46f3fcad90da0abcc0a3f73d4.js"></script> <div id='customFeatureControl' enabledFeatures="contentbackfillgenerate,esiproductcards,uhf-ms-io-endpoint,uhf-esi-cv,uhf-esi-cache,fraud-greenid,contentsquare,mediapixel,holiday-themer,lazyload-static-components,clientlibDefer,upsellEnabled,contentbackfillpkgdelete,healthcheck,demo-feature,contentbackfillhttpgenerate,perf-tracker-1ds,dynamic-bundle,cvIncrementer,tentingEnabled,chatCookiesImplemented,alertCountDownWithoutServerTime,pdpDynamicRendering,bundlesDynamicRendering,contentbackfillmetadatachangesvideo,contentbackfillmetadatachangesnonvideo,listDynamicRendering,experimentation-without-personalization,generic-list-importer,combinedUHF,cvCallEnabled,m365ProductCatalog,support-unsupported-locales,deferClickTale,videoLazyLoad,prefetchFontsEnabled,enable-code-isolation,imageLinkTag,fetchPriority,contentIngestionAgent,enableClickgroupTelemetry,imageLazyLoad,contentIngestionAgent-dispatcher2westus2Agent,isCacheControlFeatureEnabled,lcpPrioritizationPhase1,ocReimagineTelemetry,deferScriptsEnabled,lcpPrioritizationPhase2,contentIngestionAgent-dispatcher1westus2Agent,extended-html-minification-sites"></div> <div class='oneds-config' data-instrumentationkey='1cfc1aff02e4437889594f14c4cad289-5bf9ec06-73a3-4827-a5e7-d709ff3d3b12-6941' data-isenabled='true' data-env='prod' data-market='en' data-pageName='Microsoft Outlook Personal Email and Calendar | Microsoft 365' data-urlCollectQuery='true' data-urlCollectHash='false' data-autoCapturelineage='false' data-autoCaptureresize='false' data-autoCapturescroll='false' data-initialize1DSEventName="none" data-tenantName='bade' data-tenantTitle='Brand, Advocacy, Digital and Experiences' data-tenantDomain='microsoft' data-tenantSiteName='microsoft' data-tenantNameProperty='tenantName' data-tenantTitleProperty='tenantTitle' data-tenantDomainProperty='tenantDomain' data-tenantSiteNameProperty='tenantSiteName' data-max1DSInitializeDelayInSeconds='1'> </div> <script src="/etc.clientlibs/microsoft/components/structure/page/clientlibs/custom-oneds.min.ACSHASHfcb6e8a20d1f1a35b553b673e5f5403d.js"></script> <script id="onecloud-body-script" type="text/javascript" src="https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RE4OCI2" async></script> <section id="oc-contact-sales"> </section> <link rel="stylesheet" href="/etc.clientlibs/onecloud/clientlibs/clientlib-chat.min.ACSHASHfa6f56b2d3037982772378233706c9af.css" type="text/css"> <meta name="chat-default-config"/> <meta name="chat-default-locale-chat"/> <meta name="chat-default-site-type-chat"/> <meta name="chat-specific-site-type-locale-chat"/> <meta name="chat-oc-opts" value='{"chatDialogDescription": "chat with sales window", "isChatDisabled": "", "siteType": "", "disableProactiveChat": "false", "debugHostNames": ["localhost", "sites-author.adobeppe.microsoft.com"]}'/> <script src="/etc.clientlibs/onecloud/clientlibs/clientlib-chat.min.ACSHASH34e3440e73ee943fc9802fcad4720cba.js"></script> <script src="/etc.clientlibs/onecloud/clientlibs/clientlib-market-layer.min.ACSHASH551a5d1b5ebf715e3f78c311a57fa1d7.js"></script> <script type="text/javascript" src="/etc.clientlibs/cascade.component.authoring/clientlibs/clientlib-greenid.min.ACSHASH383b23d12df0d9265d7569a7102c2f96.js" async></script> </body> </html>